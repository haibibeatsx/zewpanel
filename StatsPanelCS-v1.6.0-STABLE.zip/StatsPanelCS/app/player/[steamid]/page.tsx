import PlayerProfile from './PlayerProfile'

export default function PlayerPage({ params }: { params: { steamid: string } }) {
  return <PlayerProfile steamId={params.steamid} />
}
