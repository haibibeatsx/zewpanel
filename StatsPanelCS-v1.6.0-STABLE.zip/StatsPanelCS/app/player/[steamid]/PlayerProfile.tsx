'use client'

import { useState, useEffect } from 'react'
import { Card, CardBody, CardHeader } from '@nextui-org/card'
import { Chip } from '@nextui-org/chip'
import { Spinner } from '@nextui-org/spinner'
import { Progress } from '@nextui-org/progress'
import { Button } from '@nextui-org/button'
import { IconArrowLeft, IconSword, IconSkull, IconTarget, IconClock, IconTrophy, IconFlame } from '@tabler/icons-react'
import Link from 'next/link'

interface PlayerData {
  position: number
  steamId: string
  name: string
  experience: number
  rank: string
  rankIcon: string
  nextRank: string
  nextRankExp: number
  expProgress: number
  kills: number
  deaths: number
  assists: number
  kd: number
  headshots: number
  hsPercent: number
  shoots: number
  hits: number
  accuracy: number
  roundsWon: number
  roundsLost: number
  winRate: number
  playtime: number
  lastConnect: string
}

// Achievements
const ACHIEVEMENTS = [
  { id: 'kills_100', name: 'First Blood', desc: '100 Kills', icon: '🗡️', requirement: (p: PlayerData) => p.kills >= 100 },
  { id: 'kills_500', name: 'Slayer', desc: '500 Kills', icon: '⚔️', requirement: (p: PlayerData) => p.kills >= 500 },
  { id: 'kills_1000', name: 'Terminator', desc: '1,000 Kills', icon: '💀', requirement: (p: PlayerData) => p.kills >= 1000 },
  { id: 'kills_5000', name: 'Legendary Killer', desc: '5,000 Kills', icon: '🔥', requirement: (p: PlayerData) => p.kills >= 5000 },
  { id: 'kills_10000', name: 'Death Machine', desc: '10,000 Kills', icon: '☠️', requirement: (p: PlayerData) => p.kills >= 10000 },
  { id: 'hs_100', name: 'Sharpshooter', desc: '100 Headshots', icon: '🎯', requirement: (p: PlayerData) => p.headshots >= 100 },
  { id: 'hs_500', name: 'Head Hunter', desc: '500 Headshots', icon: '💥', requirement: (p: PlayerData) => p.headshots >= 500 },
  { id: 'hs_1000', name: 'One Tap Machine', desc: '1,000 Headshots', icon: '🧠', requirement: (p: PlayerData) => p.headshots >= 1000 },
  { id: 'kd_1', name: 'Positive', desc: 'K/D ≥ 1.0', icon: '📈', requirement: (p: PlayerData) => p.kd >= 1.0 },
  { id: 'kd_1.5', name: 'Dominator', desc: 'K/D ≥ 1.5', icon: '💪', requirement: (p: PlayerData) => p.kd >= 1.5 },
  { id: 'kd_2', name: 'Unstoppable', desc: 'K/D ≥ 2.0', icon: '🏆', requirement: (p: PlayerData) => p.kd >= 2.0 },
  { id: 'hs_50', name: 'Precise', desc: 'HS% ≥ 50%', icon: '🔫', requirement: (p: PlayerData) => p.hsPercent >= 50 },
  { id: 'acc_30', name: 'Accurate', desc: 'Accuracy ≥ 30%', icon: '🎱', requirement: (p: PlayerData) => p.accuracy >= 30 },
  { id: 'playtime_10', name: 'Regular', desc: '10+ Hours', icon: '⏰', requirement: (p: PlayerData) => p.playtime >= 600 },
  { id: 'playtime_50', name: 'Veteran', desc: '50+ Hours', icon: '🎖️', requirement: (p: PlayerData) => p.playtime >= 3000 },
  { id: 'playtime_100', name: 'No-Lifer', desc: '100+ Hours', icon: '👑', requirement: (p: PlayerData) => p.playtime >= 6000 },
  { id: 'top_10', name: 'Elite', desc: 'Top 10 Player', icon: '🌟', requirement: (p: PlayerData) => p.position <= 10 },
  { id: 'top_3', name: 'Champion', desc: 'Top 3 Player', icon: '🏅', requirement: (p: PlayerData) => p.position <= 3 },
  { id: 'top_1', name: 'The Best', desc: '#1 Player', icon: '👑', requirement: (p: PlayerData) => p.position === 1 },
]

const getRankColor = (rankName: string): 'default' | 'primary' | 'secondary' | 'success' | 'warning' | 'danger' => {
  if (rankName.includes('Silver')) return 'default'
  if (rankName.includes('Gold')) return 'warning'
  if (rankName.includes('Master Guardian') || rankName.includes('Distinguished')) return 'primary'
  if (rankName.includes('Legendary') || rankName.includes('Supreme')) return 'secondary'
  if (rankName.includes('Global')) return 'danger'
  return 'default'
}

const formatPlaytime = (minutes: number) => {
  if (!minutes) return '0h'
  const hours = Math.floor(minutes / 60)
  const mins = minutes % 60
  if (hours >= 24) {
    const days = Math.floor(hours / 24)
    return `${days}d ${hours % 24}h`
  }
  return `${hours}h ${mins}m`
}

const formatDate = (dateStr: string) => {
  if (!dateStr) return 'Never'
  const date = new Date(dateStr)
  return date.toLocaleDateString('ro-RO', { 
    year: 'numeric', 
    month: 'short', 
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  })
}

export default function PlayerProfile({ steamId }: { steamId: string }) {
  const [player, setPlayer] = useState<PlayerData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    const fetchPlayer = async () => {
      try {
        const res = await fetch(`/api/ranks?action=player&steamid=${steamId}`)
        const data = await res.json()
        if (data.success) {
          setPlayer(data.data)
        } else {
          setError('Player not found')
        }
      } catch (err) {
        setError('Error loading player')
      }
      setLoading(false)
    }
    fetchPlayer()
  }, [steamId])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Spinner size="lg" />
      </div>
    )
  }

  if (error || !player) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-4">
        <p className="text-xl text-gray-400">{error || 'Player not found'}</p>
        <Link href="/ranks">
          <Button color="primary">← Back to Rankings</Button>
        </Link>
      </div>
    )
  }

  const unlockedAchievements = ACHIEVEMENTS.filter(a => a.requirement(player))
  const lockedAchievements = ACHIEVEMENTS.filter(a => !a.requirement(player))

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      {/* Back Button */}
      <Link href="/ranks" className="inline-flex items-center gap-2 text-gray-400 hover:text-white mb-6 transition-colors">
        <IconArrowLeft size={20} />
        Back to Rankings
      </Link>

      {/* Header Card */}
      <Card className="mb-6 bg-gradient-to-r from-default-100 to-default-50 overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-bl from-primary/20 to-transparent rounded-full -mr-32 -mt-32" />
        <CardBody className="p-8">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <h1 className="text-4xl font-bold">{player.name}</h1>
                {player.position <= 3 && (
                  <span className="text-3xl">
                    {player.position === 1 ? '👑' : player.position === 2 ? '🥈' : '🥉'}
                  </span>
                )}
              </div>
              <p className="text-gray-400 mb-4">Rank #{player.position} • Steam: {player.steamId}</p>
              <div className="flex items-center gap-4">
                <Chip color={getRankColor(player.rank)} size="lg" variant="shadow">
                  {player.rank}
                </Chip>
                <span className="text-2xl font-mono text-blue-400">{player.experience.toLocaleString()} XP</span>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-400">Last seen</p>
              <p className="text-lg">{formatDate(player.lastConnect)}</p>
            </div>
          </div>

          {/* Progress to next rank */}
          <div className="mt-6">
            <div className="flex justify-between text-sm mb-2">
              <span className="text-gray-400">Progress to {player.nextRank}</span>
              <span>{player.experience.toLocaleString()} / {player.nextRankExp.toLocaleString()} XP</span>
            </div>
            <Progress 
              value={player.expProgress} 
              color={getRankColor(player.rank)}
              className="h-3"
              showValueLabel
            />
          </div>
        </CardBody>
      </Card>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <Card className="bg-gradient-to-br from-green-500/20 to-green-600/10 border border-green-500/20">
          <CardBody className="text-center py-6">
            <IconSword className="mx-auto mb-2 text-green-400" size={32} />
            <p className="text-3xl font-bold text-green-400">{player.kills.toLocaleString()}</p>
            <p className="text-sm text-gray-400">Kills</p>
          </CardBody>
        </Card>
        <Card className="bg-gradient-to-br from-red-500/20 to-red-600/10 border border-red-500/20">
          <CardBody className="text-center py-6">
            <IconSkull className="mx-auto mb-2 text-red-400" size={32} />
            <p className="text-3xl font-bold text-red-400">{player.deaths.toLocaleString()}</p>
            <p className="text-sm text-gray-400">Deaths</p>
          </CardBody>
        </Card>
        <Card className="bg-gradient-to-br from-yellow-500/20 to-yellow-600/10 border border-yellow-500/20">
          <CardBody className="text-center py-6">
            <IconTarget className="mx-auto mb-2 text-yellow-400" size={32} />
            <p className="text-3xl font-bold text-yellow-400">{player.kd}</p>
            <p className="text-sm text-gray-400">K/D Ratio</p>
          </CardBody>
        </Card>
        <Card className="bg-gradient-to-br from-blue-500/20 to-blue-600/10 border border-blue-500/20">
          <CardBody className="text-center py-6">
            <IconClock className="mx-auto mb-2 text-blue-400" size={32} />
            <p className="text-3xl font-bold text-blue-400">{formatPlaytime(player.playtime)}</p>
            <p className="text-sm text-gray-400">Playtime</p>
          </CardBody>
        </Card>
      </div>

      {/* Detailed Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <Card>
          <CardHeader>
            <h3 className="text-xl font-bold flex items-center gap-2">
              <IconTarget size={24} /> Combat Stats
            </h3>
          </CardHeader>
          <CardBody className="gap-4">
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Headshots</span>
              <span className="font-bold text-yellow-400">{player.headshots.toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Headshot %</span>
              <div className="flex items-center gap-2">
                <Progress value={player.hsPercent} className="w-24" color="warning" size="sm" />
                <span className="font-bold">{player.hsPercent}%</span>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Accuracy</span>
              <div className="flex items-center gap-2">
                <Progress value={player.accuracy} className="w-24" color="primary" size="sm" />
                <span className="font-bold">{player.accuracy}%</span>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Assists</span>
              <span className="font-bold">{player.assists.toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Shots Fired</span>
              <span className="font-bold">{player.shoots?.toLocaleString() || 0}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Hits</span>
              <span className="font-bold">{player.hits?.toLocaleString() || 0}</span>
            </div>
          </CardBody>
        </Card>

        <Card>
          <CardHeader>
            <h3 className="text-xl font-bold flex items-center gap-2">
              <IconTrophy size={24} /> Match Stats
            </h3>
          </CardHeader>
          <CardBody className="gap-4">
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Rounds Won</span>
              <span className="font-bold text-green-400">{player.roundsWon.toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Rounds Lost</span>
              <span className="font-bold text-red-400">{player.roundsLost.toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Win Rate</span>
              <div className="flex items-center gap-2">
                <Progress 
                  value={parseFloat(String(player.winRate))} 
                  className="w-24" 
                  color={parseFloat(String(player.winRate)) >= 50 ? 'success' : 'danger'} 
                  size="sm" 
                />
                <span className="font-bold">{player.winRate}%</span>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Total Rounds</span>
              <span className="font-bold">{(player.roundsWon + player.roundsLost).toLocaleString()}</span>
            </div>
          </CardBody>
        </Card>
      </div>

      {/* Achievements */}
      <Card>
        <CardHeader>
          <h3 className="text-xl font-bold flex items-center gap-2">
            <IconFlame size={24} /> Achievements ({unlockedAchievements.length}/{ACHIEVEMENTS.length})
          </h3>
        </CardHeader>
        <CardBody>
          <div className="mb-4">
            <p className="text-sm text-gray-400 mb-3">Unlocked</p>
            <div className="flex flex-wrap gap-2">
              {unlockedAchievements.map(achievement => (
                <Chip
                  key={achievement.id}
                  variant="shadow"
                  color="success"
                  className="h-auto py-2"
                  startContent={<span className="text-lg">{achievement.icon}</span>}
                >
                  <div className="flex flex-col">
                    <span className="font-bold">{achievement.name}</span>
                    <span className="text-xs opacity-70">{achievement.desc}</span>
                  </div>
                </Chip>
              ))}
              {unlockedAchievements.length === 0 && (
                <p className="text-gray-500">No achievements yet</p>
              )}
            </div>
          </div>
          
          <div>
            <p className="text-sm text-gray-400 mb-3">Locked</p>
            <div className="flex flex-wrap gap-2">
              {lockedAchievements.map(achievement => (
                <Chip
                  key={achievement.id}
                  variant="flat"
                  className="h-auto py-2 opacity-50"
                  startContent={<span className="text-lg grayscale">🔒</span>}
                >
                  <div className="flex flex-col">
                    <span className="font-bold">{achievement.name}</span>
                    <span className="text-xs opacity-70">{achievement.desc}</span>
                  </div>
                </Chip>
              ))}
            </div>
          </div>
        </CardBody>
      </Card>
    </div>
  )
}
