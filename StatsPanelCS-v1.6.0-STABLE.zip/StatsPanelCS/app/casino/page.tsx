'use client'

import { useState, useEffect, useRef } from 'react'
import { Card, CardBody, CardHeader } from '@nextui-org/card'
import { Button } from '@nextui-org/button'
import { Input } from '@nextui-org/input'
import { Progress } from '@nextui-org/progress'
import { Spinner } from '@nextui-org/spinner'
import { IconCoin, IconArrowLeft, IconHistory } from '@tabler/icons-react'
import Link from 'next/link'
import useAuth from '@/utils/hooks/useAuth'

export default function CasinoPage() {
  const { user, isLoading: authLoading } = useAuth()
  
  // User balance from Store
  const [balance, setBalance] = useState<number | null>(null)
  const [loadingBalance, setLoadingBalance] = useState(true)
  const [betAmount, setBetAmount] = useState(100)
  
  // Coin Flip
  const [coinFlipResult, setCoinFlipResult] = useState<string | null>(null)
  const [coinFlipWon, setCoinFlipWon] = useState<boolean | null>(null)
  const [coinFlipping, setCoinFlipping] = useState(false)

  // Roulette
  const [rouletteNumber, setRouletteNumber] = useState<number | null>(null)
  const [rouletteColor, setRouletteColor] = useState<string | null>(null)
  const [rouletteWon, setRouletteWon] = useState<boolean | null>(null)
  const [rouletteSpinning, setRouletteSpinning] = useState(false)

  // Crash
  const [crashMultiplier, setCrashMultiplier] = useState(1.0)
  const [crashPoint, setCrashPoint] = useState<number | null>(null)
  const [crashRunning, setCrashRunning] = useState(false)
  const [crashBetPlaced, setCrashBetPlaced] = useState(false)
  const [crashCashed, setCrashCashed] = useState(false)
  const [crashResult, setCrashResult] = useState<{won: boolean, amount: number} | null>(null)
  const crashInterval = useRef<NodeJS.Timeout | null>(null)

  // History
  const [history, setHistory] = useState<Array<{game: string, result: string, amount: number}>>([])
  const [isPlaying, setIsPlaying] = useState(false)

  // Fetch balance from store
  const fetchBalance = async () => {
    if (!user?.id) {
      setLoadingBalance(false)
      return
    }
    
    try {
      const res = await fetch(`/api/store?action=credits&steamid=${user.id}`)
      const data = await res.json()
      if (data.success) {
        setBalance(data.data.credits)
      } else {
        setBalance(0)
      }
    } catch (error) {
      console.error('Error fetching balance:', error)
      setBalance(0)
    }
    setLoadingBalance(false)
  }

  useEffect(() => {
    if (!authLoading) {
      fetchBalance()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user, authLoading])

  // Cleanup crash interval
  useEffect(() => {
    return () => {
      if (crashInterval.current) {
        clearInterval(crashInterval.current)
      }
    }
  }, [])

  // ============ COIN FLIP ============
  const playCoinFlip = async (choice: 'heads' | 'tails') => {
    if (balance === null || betAmount > balance || betAmount <= 0 || isPlaying) return
    
    setIsPlaying(true)
    setCoinFlipping(true)
    setCoinFlipResult(null)
    setCoinFlipWon(null)

    try {
      const res = await fetch('/api/casino', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'play',
          game: 'coinflip',
          steamid: user?.id,
          amount: betAmount,
          choice
        })
      })

      const data = await res.json()

      // Animation delay
      await new Promise(resolve => setTimeout(resolve, 1500))

      if (data.success) {
        setCoinFlipResult(data.game.flipResult)
        setCoinFlipWon(data.won)
        setBalance(data.newBalance)
        setHistory(h => [{
          game: 'Coin Flip',
          result: data.won ? 'Win' : 'Loss',
          amount: data.netResult
        }, ...h.slice(0, 9)])
      }
    } catch (error) {
      console.error('Coinflip error:', error)
    }

    setCoinFlipping(false)
    setIsPlaying(false)
  }

  // ============ ROULETTE ============
  const playRoulette = async (choice: 'red' | 'black' | 'green') => {
    if (balance === null || betAmount > balance || betAmount <= 0 || isPlaying) return

    setIsPlaying(true)
    setRouletteSpinning(true)
    setRouletteNumber(null)
    setRouletteColor(null)
    setRouletteWon(null)

    try {
      const res = await fetch('/api/casino', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'play',
          game: 'roulette',
          steamid: user?.id,
          amount: betAmount,
          choice
        })
      })

      const data = await res.json()

      // Animation delay
      await new Promise(resolve => setTimeout(resolve, 2000))

      if (data.success) {
        setRouletteNumber(data.game.number)
        setRouletteColor(data.game.color)
        setRouletteWon(data.won)
        setBalance(data.newBalance)
        setHistory(h => [{
          game: 'Roulette',
          result: data.won ? 'Win' : 'Loss',
          amount: data.netResult
        }, ...h.slice(0, 9)])
      }
    } catch (error) {
      console.error('Roulette error:', error)
    }

    setRouletteSpinning(false)
    setIsPlaying(false)
  }

  // ============ CRASH ============
  const startCrash = async () => {
    if (balance === null || betAmount > balance || betAmount <= 0 || crashRunning || isPlaying) return

    setIsPlaying(true)
    setCrashBetPlaced(true)
    setCrashRunning(true)
    setCrashCashed(false)
    setCrashMultiplier(1.0)
    setCrashResult(null)
    setCrashPoint(null)

    // Deduct bet immediately
    setBalance(b => (b ?? 0) - betAmount)

    // Generate crash point locally (will be verified server-side on cashout)
    const generatedCrashPoint = Math.max(1.0, (100 / (Math.random() * 100 + 1)))
    setCrashPoint(generatedCrashPoint)

    // Start multiplier animation
    crashInterval.current = setInterval(() => {
      setCrashMultiplier(m => {
        const newM = m + 0.02 + (m * 0.01) // Accelerating growth
        
        if (newM >= generatedCrashPoint) {
          // CRASHED!
          if (crashInterval.current) {
            clearInterval(crashInterval.current)
            crashInterval.current = null
          }
          setCrashRunning(false)
          setCrashResult({ won: false, amount: -betAmount })
          setHistory(h => [{
            game: 'Crash',
            result: `Crashed at ${generatedCrashPoint.toFixed(2)}x`,
            amount: -betAmount
          }, ...h.slice(0, 9)])
          setIsPlaying(false)
          return generatedCrashPoint
        }
        return newM
      })
    }, 100)
  }

  const cashOutCrash = async () => {
    if (!crashRunning || crashCashed || !crashBetPlaced) return

    // Stop the game
    if (crashInterval.current) {
      clearInterval(crashInterval.current)
      crashInterval.current = null
    }

    setCrashCashed(true)
    setCrashRunning(false)

    const winAmount = Math.floor(betAmount * crashMultiplier)
    const profit = winAmount - betAmount

    // Update balance with winnings
    try {
      const res = await fetch('/api/casino', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'win',
          steamid: user?.id,
          amount: winAmount
        })
      })

      const data = await res.json()
      if (data.success) {
        setBalance(data.newBalance)
      } else {
        // Fallback to local balance update
        setBalance(b => (b ?? 0) + winAmount)
      }
    } catch (error) {
      setBalance(b => (b ?? 0) + winAmount)
    }

    setCrashResult({ won: true, amount: profit })
    setHistory(h => [{
      game: 'Crash',
      result: `Cashed at ${crashMultiplier.toFixed(2)}x`,
      amount: profit
    }, ...h.slice(0, 9)])
    setIsPlaying(false)
  }

  const resetCrash = () => {
    setCrashBetPlaced(false)
    setCrashMultiplier(1.0)
    setCrashResult(null)
    setCrashCashed(false)
    setCrashPoint(null)
  }

  // Loading state
  if (authLoading || loadingBalance) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Spinner size="lg" />
      </div>
    )
  }

  // Not logged in
  if (!user) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        <Link href="/" className="text-gray-400 hover:text-white mb-4 inline-flex items-center gap-2">
          <IconArrowLeft size={20} /> Back to Panel
        </Link>
        <Card className="mt-8">
          <CardBody className="text-center py-12">
            <IconCoin size={64} className="mx-auto mb-4 text-yellow-400 opacity-50" />
            <h2 className="text-2xl font-bold mb-2">Login Required</h2>
            <p className="text-gray-400 mb-4">You need to login with Steam to play in the Casino</p>
            <Button color="primary" as={Link} href="/api/auth/login">
              🎮 Login with Steam
            </Button>
          </CardBody>
        </Card>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      {/* Header */}
      <div className="mb-8">
        <Link href="/" className="text-gray-400 hover:text-white mb-4 inline-flex items-center gap-2">
          <IconArrowLeft size={20} /> Back to Panel
        </Link>
        <div className="flex justify-between items-center mt-6">
          <div>
            <h1 className="text-4xl font-bold flex items-center gap-3">
              🎰 Casino
            </h1>
            <p className="text-gray-400 mt-2">Play with your in-game Store credits!</p>
          </div>
          <Card className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 border border-yellow-500/30">
            <CardBody className="flex flex-row items-center gap-3 py-3 px-6">
              <IconCoin size={24} className="text-yellow-400" />
              <div>
                <p className="text-sm text-gray-400">Your Credits</p>
                <p className="text-2xl font-bold text-yellow-400">
                  {balance?.toLocaleString() ?? 0}
                </p>
              </div>
              <Button 
                size="sm" 
                variant="flat" 
                isIconOnly
                onClick={fetchBalance}
                className="ml-2"
              >
                🔄
              </Button>
            </CardBody>
          </Card>
        </div>
      </div>

      {/* Balance warning */}
      {balance !== null && balance < 100 && (
        <Card className="mb-6 bg-orange-500/20 border border-orange-500/30">
          <CardBody className="flex flex-row items-center gap-4">
            <span className="text-2xl">⚠️</span>
            <div>
              <p className="font-bold">Low Balance!</p>
              <p className="text-sm text-gray-400">
                Play on the server to earn more credits.
              </p>
            </div>
          </CardBody>
        </Card>
      )}

      {/* Bet Amount */}
      <Card className="mb-6">
        <CardBody className="flex flex-row items-center gap-4 flex-wrap">
          <span className="text-gray-400">Bet Amount:</span>
          <div className="flex gap-2 flex-wrap">
            <Button size="sm" variant="flat" onClick={() => setBetAmount(10)} isDisabled={isPlaying}>10</Button>
            <Button size="sm" variant="flat" onClick={() => setBetAmount(50)} isDisabled={isPlaying}>50</Button>
            <Button size="sm" variant="flat" onClick={() => setBetAmount(100)} isDisabled={isPlaying}>100</Button>
            <Button size="sm" variant="flat" onClick={() => setBetAmount(500)} isDisabled={isPlaying}>500</Button>
            <Button size="sm" variant="flat" onClick={() => setBetAmount(Math.floor((balance ?? 0) / 2))} isDisabled={isPlaying}>1/2</Button>
            <Button size="sm" variant="flat" onClick={() => setBetAmount(balance ?? 0)} isDisabled={isPlaying}>MAX</Button>
          </div>
          <Input
            type="number"
            value={betAmount.toString()}
            onChange={(e) => setBetAmount(parseInt(e.target.value) || 0)}
            className="w-32"
            size="sm"
            isDisabled={isPlaying}
          />
        </CardBody>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Coin Flip */}
        <Card className="bg-gradient-to-br from-blue-500/10 to-purple-500/10 border border-blue-500/20">
          <CardHeader>
            <h2 className="text-xl font-bold">🪙 Coin Flip</h2>
          </CardHeader>
          <CardBody className="text-center">
            <div className="text-6xl mb-6 h-20 flex items-center justify-center">
              {coinFlipping ? (
                <span className="animate-spin">🪙</span>
              ) : coinFlipResult ? (
                coinFlipResult === 'heads' ? '😀' : '🦅'
              ) : (
                '🪙'
              )}
            </div>
            {coinFlipWon !== null && !coinFlipping && (
              <p className={`mb-4 text-lg font-bold ${coinFlipWon ? 'text-green-400' : 'text-red-400'}`}>
                {coinFlipWon ? `🎉 You Won ${betAmount} credits!` : '😢 You Lost'}
              </p>
            )}
            <div className="flex gap-4 justify-center">
              <Button
                color="primary"
                variant="shadow"
                size="lg"
                onClick={() => playCoinFlip('heads')}
                isLoading={coinFlipping}
                isDisabled={isPlaying || betAmount > (balance ?? 0) || betAmount <= 0}
              >
                😀 Heads
              </Button>
              <Button
                color="secondary"
                variant="shadow"
                size="lg"
                onClick={() => playCoinFlip('tails')}
                isLoading={coinFlipping}
                isDisabled={isPlaying || betAmount > (balance ?? 0) || betAmount <= 0}
              >
                🦅 Tails
              </Button>
            </div>
            <p className="text-sm text-gray-500 mt-4">Win 2x your bet!</p>
          </CardBody>
        </Card>

        {/* Roulette */}
        <Card className="bg-gradient-to-br from-red-500/10 to-black/10 border border-red-500/20">
          <CardHeader>
            <h2 className="text-xl font-bold">🎡 Roulette</h2>
          </CardHeader>
          <CardBody className="text-center">
            <div className="mb-6">
              <div className={`text-4xl h-20 w-20 flex items-center justify-center rounded-full mx-auto font-bold ${
                rouletteColor === 'green' ? 'bg-green-500' :
                rouletteColor === 'red' ? 'bg-red-500' :
                rouletteColor === 'black' ? 'bg-gray-800' :
                'bg-default-100'
              }`}>
                {rouletteSpinning ? (
                  <span className="animate-pulse">?</span>
                ) : rouletteNumber !== null ? (
                  rouletteNumber
                ) : (
                  '🎡'
                )}
              </div>
            </div>
            {rouletteWon !== null && !rouletteSpinning && (
              <p className={`mb-4 text-lg font-bold ${rouletteWon ? 'text-green-400' : 'text-red-400'}`}>
                {rouletteWon ? '🎉 You Won!' : '😢 You Lost'}
              </p>
            )}
            <div className="flex gap-2 justify-center mb-4">
              <Button
                color="danger"
                variant="shadow"
                onClick={() => playRoulette('red')}
                isLoading={rouletteSpinning}
                isDisabled={isPlaying || betAmount > (balance ?? 0) || betAmount <= 0}
              >
                🔴 Red 2x
              </Button>
              <Button
                color="success"
                variant="shadow"
                onClick={() => playRoulette('green')}
                isLoading={rouletteSpinning}
                isDisabled={isPlaying || betAmount > (balance ?? 0) || betAmount <= 0}
              >
                🟢 14x
              </Button>
              <Button
                color="default"
                variant="shadow"
                onClick={() => playRoulette('black')}
                isLoading={rouletteSpinning}
                isDisabled={isPlaying || betAmount > (balance ?? 0) || betAmount <= 0}
              >
                ⚫ 2x
              </Button>
            </div>
          </CardBody>
        </Card>

        {/* Crash */}
        <Card className="bg-gradient-to-br from-yellow-500/10 to-orange-500/10 border border-yellow-500/20">
          <CardHeader>
            <h2 className="text-xl font-bold">📈 Crash</h2>
          </CardHeader>
          <CardBody className="text-center">
            <div className="mb-6">
              <p className={`text-5xl font-bold ${
                crashCashed ? 'text-green-400' : 
                crashRunning ? 'text-yellow-400 animate-pulse' : 
                crashResult && !crashResult.won ? 'text-red-400' : 
                ''
              }`}>
                {crashMultiplier.toFixed(2)}x
              </p>
              {crashRunning && (
                <Progress
                  value={Math.min((crashMultiplier - 1) * 20, 100)}
                  color="warning"
                  className="mt-4"
                />
              )}
              {crashResult && (
                <p className={`mt-2 font-bold ${crashResult.won ? 'text-green-400' : 'text-red-400'}`}>
                  {crashResult.won ? `+${crashResult.amount} credits!` : `${crashResult.amount} credits`}
                </p>
              )}
            </div>
            
            {!crashBetPlaced ? (
              <Button
                color="warning"
                variant="shadow"
                size="lg"
                onClick={startCrash}
                fullWidth
                isDisabled={isPlaying || betAmount > (balance ?? 0) || betAmount <= 0}
              >
                🚀 Start Game ({betAmount} credits)
              </Button>
            ) : crashRunning ? (
              <Button
                color="success"
                variant="shadow"
                size="lg"
                onClick={cashOutCrash}
                fullWidth
              >
                💰 Cash Out ({Math.floor(betAmount * crashMultiplier)} credits)
              </Button>
            ) : (
              <Button
                color="primary"
                variant="flat"
                size="lg"
                onClick={resetCrash}
                fullWidth
              >
                🔄 Play Again
              </Button>
            )}
            <p className="text-sm text-gray-500 mt-4">Cash out before it crashes!</p>
          </CardBody>
        </Card>
      </div>

      {/* History */}
      <Card className="mt-6">
        <CardHeader>
          <h2 className="text-xl font-bold flex items-center gap-2">
            <IconHistory size={24} />
            Recent Games
          </h2>
        </CardHeader>
        <CardBody>
          {history.length === 0 ? (
            <p className="text-center text-gray-500 py-4">No games played yet</p>
          ) : (
            <div className="space-y-2">
              {history.map((item, index) => (
                <div key={index} className="flex justify-between items-center p-3 bg-default-100 rounded-lg">
                  <div className="flex items-center gap-3">
                    <span>{item.game === 'Coin Flip' ? '🪙' : item.game === 'Roulette' ? '🎡' : '📈'}</span>
                    <span>{item.game}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-gray-400">{item.result}</span>
                    <span className={item.amount >= 0 ? 'text-green-400' : 'text-red-400'}>
                      {item.amount >= 0 ? '+' : ''}{item.amount}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardBody>
      </Card>

      {/* Info */}
      <div className="mt-6 text-center text-gray-500 text-sm">
        <p>💰 All wins and losses are saved to your account!</p>
        <p>🎮 Earn more credits by playing on the server</p>
      </div>
    </div>
  )
}
