import BansTable from './UI/Layouts/Main/Bans'
import MutesTable from './UI/Layouts/Main/Mutes'
import StatsGrid from './UI/Layouts/Main/Stats/Grid'
import Servers from './UI/Layouts/Main/Servers'
import SSRHeader from './UI/Layouts/Main/Header/SSR'
import ServersTable from './UI/Layouts/Main/Servers/Table'
import TopPlayers from './UI/Layouts/Main/TopPlayers'
import LiveServerStats from './UI/Layouts/Main/LiveServerStats'
import PlayerSearch from './UI/Layouts/Main/PlayerSearch'
import query from '@/utils/functions/db'

export const dynamic = 'force-dynamic'

const Home = async () => {
	const serversGrid = await query.settings.getByKey('serversGrid')

	return (
		<>
			<SSRHeader />
			
			{/* Search Bar */}
			<div className="flex justify-center mb-6">
				<PlayerSearch />
			</div>

			{/* Top Players & Live Server Stats */}
			<div className='grid grid-cols-1 md:grid-cols-2 gap-6 mb-6'>
				<TopPlayers />
				<LiveServerStats />
			</div>

			{/* Servers */}
			{serversGrid ? <Servers /> : <ServersTable />}
			
			{/* Stats */}
			<StatsGrid />
			
			{/* Bans & Mutes */}
			<div className='grid grid-cols-1 md:grid-cols-2 gap-6'>
				<BansTable type='SMALL' />
				<MutesTable type='SMALL' />
			</div>
		</>
	)
}

export default Home
