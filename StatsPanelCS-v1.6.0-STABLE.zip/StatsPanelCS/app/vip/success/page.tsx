'use client'

import { useEffect, useState } from 'react'
import { useSearchParams } from 'next/navigation'
import { Card, CardBody } from '@nextui-org/card'
import { Button } from '@nextui-org/button'
import { Spinner } from '@nextui-org/spinner'
import { IconCheck, IconX, IconArrowLeft } from '@tabler/icons-react'
import Link from 'next/link'

interface PaymentResult {
  success: boolean
  paid: boolean
  packageName?: string
  steamId?: string
  amount?: number
  currency?: string
}

export default function VIPSuccessPage() {
  const searchParams = useSearchParams()
  const sessionId = searchParams?.get('session_id') || null
  
  const [loading, setLoading] = useState(true)
  const [result, setResult] = useState<PaymentResult | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const verifyPayment = async () => {
      if (!sessionId) {
        setError('No session ID provided')
        setLoading(false)
        return
      }

      try {
        const res = await fetch('/api/vip/checkout', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            action: 'verify-payment',
            sessionId,
          }),
        })

        const data = await res.json()

        if (data.success) {
          setResult(data)
        } else {
          setError(data.error || 'Payment verification failed')
        }
      } catch (err: any) {
        setError(err.message || 'An error occurred')
      }

      setLoading(false)
    }

    verifyPayment()
  }, [sessionId])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="max-w-md w-full mx-4">
          <CardBody className="text-center py-12">
            <Spinner size="lg" />
            <p className="mt-4 text-gray-400">Verifying payment...</p>
          </CardBody>
        </Card>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="max-w-md w-full mx-4 bg-red-500/10 border border-red-500/30">
          <CardBody className="text-center py-12">
            <div className="w-20 h-20 mx-auto bg-red-500/20 rounded-full flex items-center justify-center mb-6">
              <IconX size={40} className="text-red-500" />
            </div>
            <h1 className="text-2xl font-bold mb-2">Payment Error</h1>
            <p className="text-gray-400 mb-6">{error}</p>
            <Button as={Link} href="/vip" color="primary">
              <IconArrowLeft size={18} />
              Back to VIP Shop
            </Button>
          </CardBody>
        </Card>
      </div>
    )
  }

  if (result?.paid) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="max-w-md w-full mx-4 bg-green-500/10 border border-green-500/30">
          <CardBody className="text-center py-12">
            <div className="w-20 h-20 mx-auto bg-green-500/20 rounded-full flex items-center justify-center mb-6">
              <IconCheck size={40} className="text-green-500" />
            </div>
            <h1 className="text-3xl font-bold mb-2">🎉 Payment Successful!</h1>
            <p className="text-gray-400 mb-6">
              Thank you for purchasing <strong>{result.packageName}</strong>!
            </p>
            
            <div className="bg-default-100 rounded-lg p-4 mb-6 text-left">
              <div className="flex justify-between mb-2">
                <span className="text-gray-400">Package:</span>
                <span className="font-bold">{result.packageName}</span>
              </div>
              <div className="flex justify-between mb-2">
                <span className="text-gray-400">Amount:</span>
                <span className="font-bold">
                  {((result.amount || 0) / 100).toFixed(2)} {result.currency?.toUpperCase()}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Steam ID:</span>
                <span className="font-mono text-sm">{result.steamId}</span>
              </div>
            </div>

            <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-4 mb-6">
              <p className="text-sm text-yellow-400">
                ⏱️ Your VIP will be activated within 5 minutes. 
                If not, please contact an admin on Discord.
              </p>
            </div>

            <div className="flex gap-3">
              <Button as={Link} href="/" color="primary" variant="flat" fullWidth>
                Go to Dashboard
              </Button>
              <Button 
                as="a" 
                href="steam://connect/51.195.117.14:27015" 
                color="success" 
                fullWidth
              >
                🎮 Play Now
              </Button>
            </div>
          </CardBody>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex items-center justify-center">
      <Card className="max-w-md w-full mx-4 bg-orange-500/10 border border-orange-500/30">
        <CardBody className="text-center py-12">
          <div className="w-20 h-20 mx-auto bg-orange-500/20 rounded-full flex items-center justify-center mb-6">
            <IconX size={40} className="text-orange-500" />
          </div>
          <h1 className="text-2xl font-bold mb-2">Payment Pending</h1>
          <p className="text-gray-400 mb-6">
            Your payment is still being processed. Please wait or try again.
          </p>
          <Button as={Link} href="/vip" color="primary">
            <IconArrowLeft size={18} />
            Back to VIP Shop
          </Button>
        </CardBody>
      </Card>
    </div>
  )
}
