'use client'

import { useState } from 'react'
import { Card, CardBody, CardHeader, CardFooter } from '@nextui-org/card'
import { Button } from '@nextui-org/button'
import { Chip } from '@nextui-org/chip'
import { Modal, ModalContent, ModalHeader, ModalBody, ModalFooter } from '@nextui-org/modal'
import { Spinner } from '@nextui-org/spinner'
import { IconCheck, IconArrowLeft } from '@tabler/icons-react'
import Link from 'next/link'
import { useSearchParams } from 'next/navigation'
import useAuth from '@/utils/hooks/useAuth'

interface VIPPackage {
  id: string
  name: string
  icon: string
  price: string
  priceValue: number
  duration: string
  color: 'warning' | 'secondary' | 'danger'
  popular?: boolean
  features: string[]
}

const vipPackages: VIPPackage[] = [
  {
    id: 'bronze',
    name: 'VIP Bronze',
    icon: '🥉',
    price: '€2.99',
    priceValue: 299,
    duration: '1 Month',
    color: 'warning',
    features: [
      'Spawn with Armor + Helmet',
      'Defuser on spawn (CT)',
      'Reserved slot',
      'Custom chat tag',
      'No flash from teammates',
    ],
  },
  {
    id: 'silver',
    name: 'VIP Silver',
    icon: '🥈',
    price: '€4.99',
    priceValue: 499,
    duration: '1 Month',
    color: 'secondary',
    popular: true,
    features: [
      'All Bronze features',
      'Auto Bunny Hop',
      'Fast defuse (2x speed)',
      '+10% damage bonus',
      'Smoke color customization',
      'Priority support',
    ],
  },
  {
    id: 'gold',
    name: 'VIP Gold',
    icon: '👑',
    price: '€7.99',
    priceValue: 799,
    duration: '1 Month',
    color: 'danger',
    features: [
      'All Silver features',
      '+20% damage bonus',
      'Decoy teleport ability',
      'Reduced gravity',
      'Extra HP regeneration',
      'Custom kill effects',
      'Exclusive chat commands',
      'Beta features access',
    ],
  },
]

export default function VIPShop() {
  const { user, isLoading: authLoading } = useAuth()
  const searchParams = useSearchParams()
  const canceled = searchParams?.get('canceled') || null
  
  const [selectedPackage, setSelectedPackage] = useState<VIPPackage | null>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [isProcessing, setIsProcessing] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleBuy = (pkg: VIPPackage) => {
    setSelectedPackage(pkg)
    setIsModalOpen(true)
    setError(null)
  }

  const handleCheckout = async () => {
    if (!selectedPackage || !user) return

    setIsProcessing(true)
    setError(null)

    try {
      const res = await fetch('/api/vip/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'create-checkout',
          packageId: selectedPackage.id,
          steamId: user.id,
          steamName: user.displayName || 'Unknown',
        }),
      })

      const data = await res.json()

      if (data.success && data.url) {
        // Redirect to Stripe Checkout
        window.location.href = data.url
      } else {
        setError(data.error || 'Failed to create checkout session')
        setIsProcessing(false)
      }
    } catch (err: any) {
      setError(err.message || 'An error occurred')
      setIsProcessing(false)
    }
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      {/* Header */}
      <div className="mb-8">
        <Link href="/" className="text-gray-400 hover:text-white mb-4 inline-flex items-center gap-2">
          <IconArrowLeft size={20} /> Back to Panel
        </Link>
        <div className="text-center mt-6">
          <h1 className="text-5xl font-bold mb-4">
            👑 VIP Shop
          </h1>
          <p className="text-xl text-gray-400">
            Get exclusive benefits and dominate the server!
          </p>
        </div>
      </div>

      {/* Canceled message */}
      {canceled && (
        <Card className="mb-6 bg-orange-500/20 border border-orange-500/30">
          <CardBody className="flex flex-row items-center gap-4">
            <span className="text-2xl">⚠️</span>
            <div>
              <p className="font-bold">Payment Canceled</p>
              <p className="text-sm text-gray-400">
                Your payment was canceled. Feel free to try again when you are ready.
              </p>
            </div>
          </CardBody>
        </Card>
      )}

      {/* Login required */}
      {!authLoading && !user && (
        <Card className="mb-6 bg-blue-500/20 border border-blue-500/30">
          <CardBody className="flex flex-row items-center gap-4">
            <span className="text-2xl">🔐</span>
            <div className="flex-1">
              <p className="font-bold">Login Required</p>
              <p className="text-sm text-gray-400">
                You need to login with Steam to purchase VIP.
              </p>
            </div>
            <Button color="primary" as={Link} href="/api/auth/login">
              Login with Steam
            </Button>
          </CardBody>
        </Card>
      )}

      {/* VIP Packages */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        {vipPackages.map((pkg) => (
          <Card
            key={pkg.id}
            className={`relative overflow-hidden ${
              pkg.popular
                ? 'border-2 border-primary shadow-lg shadow-primary/20'
                : 'border border-default-200'
            }`}
          >
            {pkg.popular && (
              <div className="absolute top-4 right-4">
                <Chip color="primary" variant="shadow" size="sm">
                  ⭐ Most Popular
                </Chip>
              </div>
            )}
            <CardHeader className="flex flex-col items-center pt-8 pb-4">
              <span className="text-6xl mb-4">{pkg.icon}</span>
              <h2 className="text-2xl font-bold">{pkg.name}</h2>
              <p className="text-gray-400">{pkg.duration}</p>
            </CardHeader>
            <CardBody className="text-center">
              <p className="text-4xl font-bold mb-6">
                {pkg.price}
                <span className="text-sm text-gray-400 font-normal">/month</span>
              </p>
              <div className="space-y-3 text-left">
                {pkg.features.map((feature, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <IconCheck size={18} className="text-green-400 flex-shrink-0" />
                    <span className="text-sm">{feature}</span>
                  </div>
                ))}
              </div>
            </CardBody>
            <CardFooter className="pt-4">
              <Button
                color={pkg.color}
                variant={pkg.popular ? 'shadow' : 'flat'}
                fullWidth
                size="lg"
                onClick={() => handleBuy(pkg)}
                isDisabled={!user}
              >
                {user ? `Buy ${pkg.name}` : 'Login to Buy'}
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      {/* Features Comparison */}
      <Card className="mb-12">
        <CardHeader>
          <h2 className="text-2xl font-bold">📋 Features Comparison</h2>
        </CardHeader>
        <CardBody>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-default-200">
                  <th className="text-left py-3 px-4">Feature</th>
                  <th className="text-center py-3 px-4">🥉 Bronze</th>
                  <th className="text-center py-3 px-4">🥈 Silver</th>
                  <th className="text-center py-3 px-4">👑 Gold</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-default-100">
                  <td className="py-3 px-4">Armor + Helmet</td>
                  <td className="text-center py-3 px-4 text-green-400">✓</td>
                  <td className="text-center py-3 px-4 text-green-400">✓</td>
                  <td className="text-center py-3 px-4 text-green-400">✓</td>
                </tr>
                <tr className="border-b border-default-100">
                  <td className="py-3 px-4">Reserved Slot</td>
                  <td className="text-center py-3 px-4 text-green-400">✓</td>
                  <td className="text-center py-3 px-4 text-green-400">✓</td>
                  <td className="text-center py-3 px-4 text-green-400">✓</td>
                </tr>
                <tr className="border-b border-default-100">
                  <td className="py-3 px-4">Auto Bunny Hop</td>
                  <td className="text-center py-3 px-4 text-gray-500">✗</td>
                  <td className="text-center py-3 px-4 text-green-400">✓</td>
                  <td className="text-center py-3 px-4 text-green-400">✓</td>
                </tr>
                <tr className="border-b border-default-100">
                  <td className="py-3 px-4">Damage Bonus</td>
                  <td className="text-center py-3 px-4 text-gray-500">✗</td>
                  <td className="text-center py-3 px-4 text-yellow-400">+10%</td>
                  <td className="text-center py-3 px-4 text-green-400">+20%</td>
                </tr>
                <tr className="border-b border-default-100">
                  <td className="py-3 px-4">Fast Defuse</td>
                  <td className="text-center py-3 px-4 text-gray-500">✗</td>
                  <td className="text-center py-3 px-4 text-green-400">✓</td>
                  <td className="text-center py-3 px-4 text-green-400">✓</td>
                </tr>
                <tr className="border-b border-default-100">
                  <td className="py-3 px-4">Decoy Teleport</td>
                  <td className="text-center py-3 px-4 text-gray-500">✗</td>
                  <td className="text-center py-3 px-4 text-gray-500">✗</td>
                  <td className="text-center py-3 px-4 text-green-400">✓</td>
                </tr>
                <tr>
                  <td className="py-3 px-4">Custom Effects</td>
                  <td className="text-center py-3 px-4 text-gray-500">✗</td>
                  <td className="text-center py-3 px-4 text-gray-500">✗</td>
                  <td className="text-center py-3 px-4 text-green-400">✓</td>
                </tr>
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>

      {/* FAQ */}
      <Card>
        <CardHeader>
          <h2 className="text-2xl font-bold">❓ FAQ</h2>
        </CardHeader>
        <CardBody className="space-y-4">
          <div>
            <h3 className="font-bold text-lg">How do I get VIP after purchase?</h3>
            <p className="text-gray-400">VIP is automatically activated within 5 minutes of payment. Make sure you are logged in with your Steam account.</p>
          </div>
          <div>
            <h3 className="font-bold text-lg">Can I upgrade my VIP?</h3>
            <p className="text-gray-400">Yes! If you upgrade, you will only pay the difference for the remaining time.</p>
          </div>
          <div>
            <h3 className="font-bold text-lg">What payment methods do you accept?</h3>
            <p className="text-gray-400">We accept all major credit/debit cards through Stripe (Visa, Mastercard, etc.).</p>
          </div>
          <div>
            <h3 className="font-bold text-lg">Is VIP refundable?</h3>
            <p className="text-gray-400">We offer refunds within 24 hours if you have not used VIP features.</p>
          </div>
        </CardBody>
      </Card>

      {/* Payment info */}
      <div className="mt-8 text-center text-gray-500 text-sm">
        <p>🔒 Secure payments powered by Stripe</p>
        <p>💳 We accept Visa, Mastercard, and more</p>
      </div>

      {/* Purchase Modal */}
      <Modal isOpen={isModalOpen} onClose={() => !isProcessing && setIsModalOpen(false)} size="lg">
        <ModalContent>
          {selectedPackage && (
            <>
              <ModalHeader className="flex flex-col gap-1">
                <span className="text-2xl">{selectedPackage.icon} Purchase {selectedPackage.name}</span>
              </ModalHeader>
              <ModalBody>
                <div className="text-center py-4">
                  <p className="text-4xl font-bold mb-2">{selectedPackage.price}</p>
                  <p className="text-gray-400">{selectedPackage.duration}</p>
                </div>
                <div className="bg-default-100 rounded-lg p-4">
                  <p className="font-bold mb-2">You will get:</p>
                  <ul className="space-y-1">
                    {selectedPackage.features.map((feature, index) => (
                      <li key={index} className="flex items-center gap-2 text-sm">
                        <IconCheck size={16} className="text-green-400" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>

                {user && (
                  <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4 mt-4">
                    <p className="text-sm">
                      <strong>Steam Account:</strong> {user.displayName}
                    </p>
                    <p className="text-xs text-gray-400 mt-1">
                      VIP will be activated for this account
                    </p>
                  </div>
                )}

                {error && (
                  <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4 mt-4">
                    <p className="text-sm text-red-400">{error}</p>
                  </div>
                )}

                <p className="text-sm text-gray-500 text-center mt-4">
                  By purchasing, you agree to our Terms of Service
                </p>
              </ModalBody>
              <ModalFooter>
                <Button 
                  variant="flat" 
                  onClick={() => setIsModalOpen(false)}
                  isDisabled={isProcessing}
                >
                  Cancel
                </Button>
                <Button 
                  color="primary" 
                  variant="shadow"
                  onClick={handleCheckout}
                  isLoading={isProcessing}
                  isDisabled={isProcessing}
                >
                  {isProcessing ? 'Processing...' : '💳 Pay with Card'}
                </Button>
              </ModalFooter>
            </>
          )}
        </ModalContent>
      </Modal>
    </div>
  )
}
