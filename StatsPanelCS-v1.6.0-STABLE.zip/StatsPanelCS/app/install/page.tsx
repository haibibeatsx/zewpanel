'use client'

import { useState, useEffect } from 'react'
import { Card, CardBody, CardHeader } from '@nextui-org/card'
import { Input } from '@nextui-org/input'
import { Button } from '@nextui-org/button'
import { Spinner } from '@nextui-org/spinner'
import { Progress } from '@nextui-org/progress'
import { 
  IconCheck, 
  IconX, 
  IconDatabase, 
  IconKey, 
  IconWorld,
  IconServer,
  IconUser,
  IconLock,
  IconBrandSteam,
  IconRocket
} from '@tabler/icons-react'

interface StepStatus {
  status: 'pending' | 'loading' | 'success' | 'error'
  message?: string
}

interface InstallData {
  // License
  licenseKey: string
  licensedDomain: string
  licenseEmail: string
  // Steam
  steamApiKey: string
  // Domain
  domain: string
  // Database
  dbHost: string
  dbPort: string
  dbUser: string
  dbPassword: string
  dbDatabase: string
  // Master Admin
  masterAdmin: string
  sessionSecret: string
  // Ranks DB (optional)
  ranksDbHost: string
  ranksDbPort: string
  ranksDbUser: string
  ranksDbPassword: string
  ranksDbDatabase: string
  // Store DB (optional)
  storeDbHost: string
  storeDbPort: string
  storeDbUser: string
  storeDbPassword: string
  storeDbDatabase: string
}

const INITIAL_DATA: InstallData = {
  licenseKey: '',
  licensedDomain: '',
  licenseEmail: '',
  steamApiKey: '',
  domain: '',
  dbHost: '127.0.0.1',
  dbPort: '3306',
  dbUser: '',
  dbPassword: '',
  dbDatabase: '',
  masterAdmin: '',
  sessionSecret: Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15),
  ranksDbHost: '',
  ranksDbPort: '3306',
  ranksDbUser: '',
  ranksDbPassword: '',
  ranksDbDatabase: '',
  storeDbHost: '',
  storeDbPort: '3306',
  storeDbUser: '',
  storeDbPassword: '',
  storeDbDatabase: '',
}

export default function InstallPage() {
  const [step, setStep] = useState(1)
  const [data, setData] = useState<InstallData>(INITIAL_DATA)
  const [installing, setInstalling] = useState(false)
  const [installProgress, setInstallProgress] = useState(0)
  const [installStep, setInstallStep] = useState('')
  const [stepStatuses, setStepStatuses] = useState<Record<string, StepStatus>>({})
  const [installComplete, setInstallComplete] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const updateData = (field: keyof InstallData, value: string) => {
    setData(prev => ({ ...prev, [field]: value }))
  }

  const validateStep = (stepNum: number): boolean => {
    switch (stepNum) {
      case 1: // License
        return data.licenseKey.startsWith('SPCS-') && data.licensedDomain.length > 0 && data.licenseEmail.includes('@')
      case 2: // Steam & Domain
        return data.steamApiKey.length > 20 && data.domain.startsWith('http')
      case 3: // Database
        return data.dbHost.length > 0 && data.dbUser.length > 0 && data.dbDatabase.length > 0
      case 4: // Admin
        return data.masterAdmin.length > 10
      case 5: // Optional DBs
        return true // Optional
      default:
        return false
    }
  }

  const runInstall = async () => {
    setInstalling(true)
    setError(null)
    
    const steps = [
      { key: 'license', name: 'Verifying license...', progress: 10 },
      { key: 'database', name: 'Testing database connection...', progress: 30 },
      { key: 'tables', name: 'Creating tables...', progress: 50 },
      { key: 'config', name: 'Saving configuration...', progress: 70 },
      { key: 'admin', name: 'Setting up admin...', progress: 90 },
      { key: 'complete', name: 'Finishing installation...', progress: 100 },
    ]

    for (const s of steps) {
      setInstallStep(s.name)
      setInstallProgress(s.progress)
      setStepStatuses(prev => ({ ...prev, [s.key]: { status: 'loading' } }))
      
      try {
        const res = await fetch('/api/install/step', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ step: s.key, data })
        })
        
        const result = await res.json()
        
        if (!result.success) {
          throw new Error(result.error || 'Step failed')
        }
        
        setStepStatuses(prev => ({ ...prev, [s.key]: { status: 'success', message: result.message } }))
        
        // Small delay for UX
        await new Promise(r => setTimeout(r, 500))
      } catch (err: any) {
        setStepStatuses(prev => ({ ...prev, [s.key]: { status: 'error', message: err.message } }))
        setError(err.message)
        setInstalling(false)
        return
      }
    }

    setInstallComplete(true)
    setInstalling(false)
  }

  // Check if already installed
  useEffect(() => {
    fetch('/api/install/status')
      .then(r => r.json())
      .then(data => {
        if (data.installed) {
          window.location.href = '/'
        }
      })
      .catch(() => {})
  }, [])

  const totalSteps = 6

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl bg-black/50 backdrop-blur-xl border border-white/10">
        <CardHeader className="flex flex-col items-center pt-8 pb-4">
          <div className="text-4xl mb-2">🎮</div>
          <h1 className="text-2xl font-bold text-white">StatsPanelCS Installer</h1>
          <p className="text-gray-400">v1.4.0 by ElProfessor</p>
          
          {!installComplete && (
            <div className="w-full mt-6">
              <div className="flex justify-between text-sm text-gray-400 mb-2">
                <span>Step {step} of {totalSteps}</span>
                <span>{Math.round((step / totalSteps) * 100)}%</span>
              </div>
              <Progress 
                value={(step / totalSteps) * 100} 
                color="secondary"
                className="h-2"
              />
            </div>
          )}
        </CardHeader>

        <CardBody className="px-8 pb-8">
          {installComplete ? (
            <div className="text-center py-8">
              <div className="text-6xl mb-4">🎉</div>
              <h2 className="text-2xl font-bold text-green-400 mb-2">Installation Complete!</h2>
              <p className="text-gray-400 mb-6">StatsPanelCS has been successfully installed.</p>
              <Button
                color="success"
                size="lg"
                onClick={() => window.location.href = '/'}
                startContent={<IconRocket size={20} />}
              >
                Go to Dashboard
              </Button>
            </div>
          ) : installing ? (
            <div className="py-8">
              <div className="text-center mb-6">
                <Spinner size="lg" color="secondary" />
                <p className="text-white mt-4">{installStep}</p>
              </div>
              
              <Progress 
                value={installProgress} 
                color="secondary" 
                className="mb-6"
                showValueLabel
              />

              <div className="space-y-2">
                {Object.entries(stepStatuses).map(([key, status]) => (
                  <div key={key} className="flex items-center gap-2 text-sm">
                    {status.status === 'loading' && <Spinner size="sm" />}
                    {status.status === 'success' && <IconCheck className="text-green-400" size={18} />}
                    {status.status === 'error' && <IconX className="text-red-400" size={18} />}
                    {status.status === 'pending' && <div className="w-[18px]" />}
                    <span className={
                      status.status === 'success' ? 'text-green-400' :
                      status.status === 'error' ? 'text-red-400' :
                      'text-gray-400'
                    }>
                      {key.charAt(0).toUpperCase() + key.slice(1)}
                      {status.message && `: ${status.message}`}
                    </span>
                  </div>
                ))}
              </div>

              {error && (
                <div className="mt-4 p-4 bg-red-500/20 border border-red-500/50 rounded-lg text-red-400">
                  {error}
                </div>
              )}
            </div>
          ) : (
            <>
              {/* Step 1: License */}
              {step === 1 && (
                <div className="space-y-4">
                  <h2 className="text-xl font-bold text-white flex items-center gap-2">
                    <IconKey className="text-yellow-400" />
                    License Information
                  </h2>
                  <p className="text-gray-400 text-sm">Enter your license key received after purchase.</p>
                  
                  <Input
                    label="License Key"
                    placeholder="SPCS-XXXX-XXXX-XXXX-XXXX"
                    value={data.licenseKey}
                    onChange={(e) => updateData('licenseKey', e.target.value.toUpperCase())}
                    startContent={<IconKey size={18} className="text-gray-400" />}
                  />
                  <Input
                    label="Licensed Domain"
                    placeholder="stats.example.com"
                    value={data.licensedDomain}
                    onChange={(e) => updateData('licensedDomain', e.target.value)}
                    startContent={<IconWorld size={18} className="text-gray-400" />}
                  />
                  <Input
                    label="License Email"
                    placeholder="your@email.com"
                    type="email"
                    value={data.licenseEmail}
                    onChange={(e) => updateData('licenseEmail', e.target.value)}
                  />
                </div>
              )}

              {/* Step 2: Steam & Domain */}
              {step === 2 && (
                <div className="space-y-4">
                  <h2 className="text-xl font-bold text-white flex items-center gap-2">
                    <IconBrandSteam className="text-blue-400" />
                    Steam & Domain
                  </h2>
                  
                  <Input
                    label="Steam API Key"
                    placeholder="Your Steam API Key"
                    value={data.steamApiKey}
                    onChange={(e) => updateData('steamApiKey', e.target.value)}
                    description={
                      <a href="https://steamcommunity.com/dev/apikey" target="_blank" className="text-blue-400">
                        Get your key here →
                      </a>
                    }
                  />
                  <Input
                    label="Panel Domain"
                    placeholder="https://stats.example.com"
                    value={data.domain}
                    onChange={(e) => updateData('domain', e.target.value)}
                    startContent={<IconWorld size={18} className="text-gray-400" />}
                  />
                </div>
              )}

              {/* Step 3: Database */}
              {step === 3 && (
                <div className="space-y-4">
                  <h2 className="text-xl font-bold text-white flex items-center gap-2">
                    <IconDatabase className="text-green-400" />
                    CS2-SimpleAdmin Database
                  </h2>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <Input
                      label="Host"
                      placeholder="127.0.0.1"
                      value={data.dbHost}
                      onChange={(e) => updateData('dbHost', e.target.value)}
                    />
                    <Input
                      label="Port"
                      placeholder="3306"
                      value={data.dbPort}
                      onChange={(e) => updateData('dbPort', e.target.value)}
                    />
                  </div>
                  <Input
                    label="Username"
                    placeholder="database_user"
                    value={data.dbUser}
                    onChange={(e) => updateData('dbUser', e.target.value)}
                    startContent={<IconUser size={18} className="text-gray-400" />}
                  />
                  <Input
                    label="Password"
                    type="password"
                    placeholder="••••••••"
                    value={data.dbPassword}
                    onChange={(e) => updateData('dbPassword', e.target.value)}
                    startContent={<IconLock size={18} className="text-gray-400" />}
                  />
                  <Input
                    label="Database Name"
                    placeholder="simpleadmin_db"
                    value={data.dbDatabase}
                    onChange={(e) => updateData('dbDatabase', e.target.value)}
                    startContent={<IconDatabase size={18} className="text-gray-400" />}
                  />
                </div>
              )}

              {/* Step 4: Admin */}
              {step === 4 && (
                <div className="space-y-4">
                  <h2 className="text-xl font-bold text-white flex items-center gap-2">
                    <IconUser className="text-purple-400" />
                    Master Admin
                  </h2>
                  
                  <Input
                    label="Your Steam64 ID"
                    placeholder="76561198000000000"
                    value={data.masterAdmin}
                    onChange={(e) => updateData('masterAdmin', e.target.value)}
                    description="This will have full access to admin panel"
                  />
                  <Input
                    label="Session Secret"
                    value={data.sessionSecret}
                    onChange={(e) => updateData('sessionSecret', e.target.value)}
                    description="Random string for session encryption (auto-generated)"
                  />
                </div>
              )}

              {/* Step 5: Optional DBs */}
              {step === 5 && (
                <div className="space-y-4">
                  <h2 className="text-xl font-bold text-white flex items-center gap-2">
                    <IconDatabase className="text-orange-400" />
                    Optional Databases
                  </h2>
                  <p className="text-gray-400 text-sm">Leave empty if not using these plugins.</p>
                  
                  <div className="p-4 bg-white/5 rounded-lg space-y-3">
                    <h3 className="font-semibold text-white">RanksCore Database</h3>
                    <div className="grid grid-cols-2 gap-3">
                      <Input size="sm" label="Host" value={data.ranksDbHost} onChange={(e) => updateData('ranksDbHost', e.target.value)} />
                      <Input size="sm" label="Port" value={data.ranksDbPort} onChange={(e) => updateData('ranksDbPort', e.target.value)} />
                      <Input size="sm" label="User" value={data.ranksDbUser} onChange={(e) => updateData('ranksDbUser', e.target.value)} />
                      <Input size="sm" label="Password" type="password" value={data.ranksDbPassword} onChange={(e) => updateData('ranksDbPassword', e.target.value)} />
                    </div>
                    <Input size="sm" label="Database" value={data.ranksDbDatabase} onChange={(e) => updateData('ranksDbDatabase', e.target.value)} />
                  </div>

                  <div className="p-4 bg-white/5 rounded-lg space-y-3">
                    <h3 className="font-semibold text-white">CS2-Store Database</h3>
                    <div className="grid grid-cols-2 gap-3">
                      <Input size="sm" label="Host" value={data.storeDbHost} onChange={(e) => updateData('storeDbHost', e.target.value)} />
                      <Input size="sm" label="Port" value={data.storeDbPort} onChange={(e) => updateData('storeDbPort', e.target.value)} />
                      <Input size="sm" label="User" value={data.storeDbUser} onChange={(e) => updateData('storeDbUser', e.target.value)} />
                      <Input size="sm" label="Password" type="password" value={data.storeDbPassword} onChange={(e) => updateData('storeDbPassword', e.target.value)} />
                    </div>
                    <Input size="sm" label="Database" value={data.storeDbDatabase} onChange={(e) => updateData('storeDbDatabase', e.target.value)} />
                  </div>
                </div>
              )}

              {/* Step 6: Review */}
              {step === 6 && (
                <div className="space-y-4">
                  <h2 className="text-xl font-bold text-white flex items-center gap-2">
                    <IconRocket className="text-green-400" />
                    Ready to Install
                  </h2>
                  
                  <div className="space-y-2 text-sm">
                    <div className="p-3 bg-white/5 rounded-lg">
                      <span className="text-gray-400">License:</span>
                      <span className="text-white ml-2">{data.licenseKey}</span>
                    </div>
                    <div className="p-3 bg-white/5 rounded-lg">
                      <span className="text-gray-400">Domain:</span>
                      <span className="text-white ml-2">{data.domain}</span>
                    </div>
                    <div className="p-3 bg-white/5 rounded-lg">
                      <span className="text-gray-400">Database:</span>
                      <span className="text-white ml-2">{data.dbUser}@{data.dbHost}/{data.dbDatabase}</span>
                    </div>
                    <div className="p-3 bg-white/5 rounded-lg">
                      <span className="text-gray-400">Master Admin:</span>
                      <span className="text-white ml-2">{data.masterAdmin}</span>
                    </div>
                  </div>

                  <div className="p-4 bg-yellow-500/20 border border-yellow-500/50 rounded-lg text-yellow-400 text-sm">
                    ⚠️ Make sure all information is correct before installing. This will create the configuration file.
                  </div>
                </div>
              )}

              {/* Navigation */}
              <div className="flex justify-between mt-8">
                <Button
                  variant="flat"
                  onClick={() => setStep(s => s - 1)}
                  isDisabled={step === 1}
                >
                  Back
                </Button>
                
                {step < 6 ? (
                  <Button
                    color="primary"
                    onClick={() => setStep(s => s + 1)}
                    isDisabled={!validateStep(step)}
                  >
                    Next
                  </Button>
                ) : (
                  <Button
                    color="success"
                    onClick={runInstall}
                    startContent={<IconRocket size={18} />}
                  >
                    Install Now
                  </Button>
                )}
              </div>
            </>
          )}
        </CardBody>
      </Card>
    </div>
  )
}
