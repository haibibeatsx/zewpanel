export default function InstallLayout({ children }: { children: React.ReactNode }) {
  return children
}
