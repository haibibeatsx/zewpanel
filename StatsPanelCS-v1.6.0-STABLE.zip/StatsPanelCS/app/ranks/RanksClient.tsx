'use client'

import { useState, useEffect } from 'react'
import { Card, CardBody, CardHeader } from '@nextui-org/card'
import { Table, TableHeader, TableColumn, TableBody, TableRow, TableCell } from '@nextui-org/table'
import { Input } from '@nextui-org/input'
import { Pagination } from '@nextui-org/pagination'
import { Chip } from '@nextui-org/chip'
import { Spinner } from '@nextui-org/spinner'
import { Progress } from '@nextui-org/progress'
import Link from 'next/link'

interface Player {
  position: number
  steamId: string
  name: string
  experience: number
  rank: string
  rankIcon: string
  nextRank: string
  nextRankExp: number
  kills: number
  deaths: number
  assists: number
  kd: number
  headshots: number
  hsPercent: number
  roundsWon: number
  roundsLost: number
  playtime: number
  lastConnect: string
  expProgress?: number
  accuracy?: number
  winRate?: number
}

interface Stats {
  totalPlayers: number
  totalKills: number
  totalDeaths: number
  totalHeadshots: number
  totalPlaytime: number
  avgExperience: number
}

const getRankColor = (rankName: string): 'default' | 'primary' | 'secondary' | 'success' | 'warning' | 'danger' => {
  if (rankName.includes('Silver')) return 'default'
  if (rankName.includes('Gold')) return 'warning'
  if (rankName.includes('Master Guardian') || rankName.includes('Distinguished')) return 'primary'
  if (rankName.includes('Legendary') || rankName.includes('Supreme')) return 'secondary'
  if (rankName.includes('Global')) return 'danger'
  return 'default'
}

const formatPlaytime = (minutes: number) => {
  if (!minutes) return '0h'
  const hours = Math.floor(minutes / 60)
  const mins = minutes % 60
  if (hours > 24) {
    const days = Math.floor(hours / 24)
    return `${days}d ${hours % 24}h`
  }
  return `${hours}h ${mins}m`
}

export default function RanksClient() {
  const [players, setPlayers] = useState<Player[]>([])
  const [loading, setLoading] = useState(true)
  const [page, setPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [search, setSearch] = useState('')
  const [searchResults, setSearchResults] = useState<Player[]>([])
  const [searching, setSearching] = useState(false)
  const [stats, setStats] = useState<Stats | null>(null)
  const [selectedPlayer, setSelectedPlayer] = useState<Player | null>(null)

  const fetchLeaderboard = async (pageNum = 1) => {
    setLoading(true)
    try {
      const res = await fetch(`/api/ranks?action=leaderboard&page=${pageNum}&limit=20`)
      const data = await res.json()
      if (data.success) {
        setPlayers(data.data.players)
        setTotalPages(data.data.pagination.totalPages)
      }
    } catch (error) {
      console.error('Error fetching leaderboard:', error)
    }
    setLoading(false)
  }

  const fetchStats = async () => {
    try {
      const res = await fetch('/api/ranks?action=stats')
      const data = await res.json()
      if (data.success) {
        setStats(data.data)
      }
    } catch (error) {
      console.error('Error fetching stats:', error)
    }
  }

  const handleSearch = async (query: string) => {
    if (!query || query.length < 2) {
      setSearchResults([])
      return
    }
    setSearching(true)
    try {
      const res = await fetch(`/api/ranks?action=search&search=${encodeURIComponent(query)}`)
      const data = await res.json()
      if (data.success) {
        setSearchResults(data.data)
      }
    } catch (error) {
      console.error('Error searching:', error)
    }
    setSearching(false)
  }

  const fetchPlayer = async (steamId: string) => {
    try {
      const res = await fetch(`/api/ranks?action=player&steamid=${steamId}`)
      const data = await res.json()
      if (data.success) {
        setSelectedPlayer(data.data)
      }
    } catch (error) {
      console.error('Error fetching player:', error)
    }
  }

  useEffect(() => {
    fetchLeaderboard(page)
    fetchStats()
  }, [page])

  useEffect(() => {
    const timer = setTimeout(() => {
      handleSearch(search)
    }, 300)
    return () => clearTimeout(timer)
  }, [search])

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-gray-950">
      {/* Simple Nav */}
      <nav className="bg-gray-800/50 border-b border-gray-700 py-4 px-6">
        <div className="container mx-auto flex justify-between items-center">
          <Link href="/" className="text-xl font-bold text-white hover:text-blue-400 transition-colors">
            ← Back to Panel
          </Link>
          <div className="flex items-center gap-4">
            <Link href="/compare" className="px-4 py-2 bg-primary/20 hover:bg-primary/30 text-primary rounded-lg transition-colors">
              ⚔️ Compare Players
            </Link>
            <h1 className="text-xl font-bold text-white">🏆 Player Rankings</h1>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Header */}
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-bold mb-2 text-white flex items-center justify-center gap-3">
            🏆 Player Rankings
          </h1>
          <p className="text-gray-400">Compete with other players and climb the ranks!</p>
        </div>

        {/* Stats Cards */}
        {stats && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <Card className="bg-gradient-to-br from-blue-500/20 to-blue-600/10 border border-blue-500/20">
              <CardBody className="text-center py-4">
                <p className="text-3xl font-bold text-blue-400">{stats.totalPlayers?.toLocaleString()}</p>
                <p className="text-sm text-gray-400">Total Players</p>
              </CardBody>
            </Card>
            <Card className="bg-gradient-to-br from-red-500/20 to-red-600/10 border border-red-500/20">
              <CardBody className="text-center py-4">
                <p className="text-3xl font-bold text-red-400">{stats.totalKills?.toLocaleString()}</p>
                <p className="text-sm text-gray-400">Total Kills</p>
              </CardBody>
            </Card>
            <Card className="bg-gradient-to-br from-yellow-500/20 to-yellow-600/10 border border-yellow-500/20">
              <CardBody className="text-center py-4">
                <p className="text-3xl font-bold text-yellow-400">{stats.totalHeadshots?.toLocaleString()}</p>
                <p className="text-sm text-gray-400">Headshots</p>
              </CardBody>
            </Card>
            <Card className="bg-gradient-to-br from-green-500/20 to-green-600/10 border border-green-500/20">
              <CardBody className="text-center py-4">
                <p className="text-3xl font-bold text-green-400">{Math.round(stats.avgExperience || 0)}</p>
                <p className="text-sm text-gray-400">Avg Experience</p>
              </CardBody>
            </Card>
          </div>
        )}

        {/* Search */}
        <div className="mb-6 relative">
          <Input
            placeholder="Search player by name..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            size="lg"
            classNames={{
              input: 'bg-transparent text-white',
              inputWrapper: 'bg-gray-800/50 border border-gray-700',
            }}
          />

          {/* Search Results Dropdown */}
          {searchResults.length > 0 && (
            <Card className="absolute z-50 w-full mt-2 max-h-80 overflow-auto bg-gray-800 border border-gray-700">
              <CardBody className="p-2">
                {searchResults.map((player) => (
                  <div
                    key={player.steamId}
                    className="flex items-center justify-between p-3 hover:bg-gray-700 rounded-lg cursor-pointer transition-colors"
                    onClick={() => {
                      fetchPlayer(player.steamId)
                      setSearch('')
                      setSearchResults([])
                    }}
                  >
                    <div className="flex items-center gap-3">
                      <div>
                        <p className="font-semibold text-white">{player.name}</p>
                        <p className="text-sm text-gray-400">{player.experience} XP</p>
                      </div>
                    </div>
                    <Chip color={getRankColor(player.rank)} size="sm" variant="flat">
                      {player.rank}
                    </Chip>
                  </div>
                ))}
              </CardBody>
            </Card>
          )}
        </div>

        {/* Selected Player Modal/Card */}
        {selectedPlayer && (
          <Card className="mb-6 bg-gradient-to-r from-gray-800 to-gray-800/50 border border-gray-700">
            <CardBody className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h2 className="text-2xl font-bold text-white">{selectedPlayer.name}</h2>
                  <p className="text-gray-400">Position #{selectedPlayer.position}</p>
                </div>
                <button
                  onClick={() => setSelectedPlayer(null)}
                  className="text-gray-400 hover:text-white text-xl"
                >
                  ✕
                </button>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                <div className="text-center">
                  <Chip color={getRankColor(selectedPlayer.rank)} size="lg" variant="shadow">
                    {selectedPlayer.rank}
                  </Chip>
                  <p className="text-sm text-gray-400 mt-2">{selectedPlayer.experience} XP</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-green-400">{selectedPlayer.kills}</p>
                  <p className="text-sm text-gray-400">Kills</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-red-400">{selectedPlayer.deaths}</p>
                  <p className="text-sm text-gray-400">Deaths</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-yellow-400">{selectedPlayer.kd}</p>
                  <p className="text-sm text-gray-400">K/D Ratio</p>
                </div>
              </div>

              <div className="mb-4">
                <div className="flex justify-between text-sm mb-1 text-gray-300">
                  <span>Progress to {selectedPlayer.nextRank}</span>
                  <span>{selectedPlayer.experience} / {selectedPlayer.nextRankExp} XP</span>
                </div>
                <Progress
                  value={parseFloat(String(selectedPlayer.expProgress || 0))}
                  color={getRankColor(selectedPlayer.rank)}
                  className="h-2"
                />
              </div>

              <div className="grid grid-cols-3 md:grid-cols-6 gap-2 text-center text-sm">
                <div className="bg-gray-700/50 rounded-lg p-2">
                  <p className="font-bold text-white">{selectedPlayer.hsPercent}%</p>
                  <p className="text-gray-400">HS%</p>
                </div>
                <div className="bg-gray-700/50 rounded-lg p-2">
                  <p className="font-bold text-white">{selectedPlayer.accuracy || 0}%</p>
                  <p className="text-gray-400">Accuracy</p>
                </div>
                <div className="bg-gray-700/50 rounded-lg p-2">
                  <p className="font-bold text-white">{selectedPlayer.assists}</p>
                  <p className="text-gray-400">Assists</p>
                </div>
                <div className="bg-gray-700/50 rounded-lg p-2">
                  <p className="font-bold text-white">{selectedPlayer.roundsWon}</p>
                  <p className="text-gray-400">Rounds W</p>
                </div>
                <div className="bg-gray-700/50 rounded-lg p-2">
                  <p className="font-bold text-white">{selectedPlayer.roundsLost}</p>
                  <p className="text-gray-400">Rounds L</p>
                </div>
                <div className="bg-gray-700/50 rounded-lg p-2">
                  <p className="font-bold text-white">{formatPlaytime(selectedPlayer.playtime)}</p>
                  <p className="text-gray-400">Playtime</p>
                </div>
              </div>
            </CardBody>
          </Card>
        )}

        {/* Leaderboard Table */}
        <Card className="bg-gray-800/50 border border-gray-700">
          <CardHeader className="flex justify-between border-b border-gray-700 pb-4">
            <h3 className="text-xl font-bold text-white">🏆 Leaderboard</h3>
          </CardHeader>
          <CardBody>
            {loading ? (
              <div className="flex justify-center py-8">
                <Spinner size="lg" color="primary" />
              </div>
            ) : (
              <>
                <Table
                  aria-label="Player rankings"
                  classNames={{
                    wrapper: 'bg-transparent shadow-none',
                    th: 'bg-gray-700/50 text-gray-300',
                    td: 'text-gray-200',
                  }}
                >
                  <TableHeader>
                    <TableColumn>#</TableColumn>
                    <TableColumn>PLAYER</TableColumn>
                    <TableColumn>RANK</TableColumn>
                    <TableColumn>XP</TableColumn>
                    <TableColumn>KILLS</TableColumn>
                    <TableColumn>DEATHS</TableColumn>
                    <TableColumn>K/D</TableColumn>
                    <TableColumn>HS%</TableColumn>
                  </TableHeader>
                  <TableBody>
                    {players.map((player) => (
                      <TableRow
                        key={player.steamId}
                        className="cursor-pointer hover:bg-gray-700/50 transition-colors"
                        onClick={() => fetchPlayer(player.steamId)}
                      >
                        <TableCell>
                          <span className={`font-bold ${player.position === 1 ? 'text-yellow-500 text-xl' :
                            player.position === 2 ? 'text-gray-400 text-lg' :
                              player.position === 3 ? 'text-amber-600 text-lg' : 'text-gray-300'
                            }`}>
                            {player.position === 1 ? '🥇' :
                              player.position === 2 ? '🥈' :
                                player.position === 3 ? '🥉' : `#${player.position}`}
                          </span>
                        </TableCell>
                        <TableCell>
                          <div className="font-semibold text-white">{player.name}</div>
                        </TableCell>
                        <TableCell>
                          <Chip
                            color={getRankColor(player.rank)}
                            size="sm"
                            variant="flat"
                          >
                            {player.rank}
                          </Chip>
                        </TableCell>
                        <TableCell>
                          <span className="text-blue-400 font-mono">
                            {player.experience.toLocaleString()}
                          </span>
                        </TableCell>
                        <TableCell>
                          <span className="text-green-400">{player.kills.toLocaleString()}</span>
                        </TableCell>
                        <TableCell>
                          <span className="text-red-400">{player.deaths.toLocaleString()}</span>
                        </TableCell>
                        <TableCell>
                          <span className={player.kd >= 1 ? 'text-green-400' : 'text-red-400'}>
                            {player.kd}
                          </span>
                        </TableCell>
                        <TableCell>
                          <span className="text-yellow-400">{player.hsPercent}%</span>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>

                {/* Pagination */}
                <div className="flex justify-center mt-4">
                  <Pagination
                    total={totalPages}
                    page={page}
                    onChange={setPage}
                    showControls
                    color="primary"
                  />
                </div>
              </>
            )}
          </CardBody>
        </Card>
      </div>
    </div>
  )
}
