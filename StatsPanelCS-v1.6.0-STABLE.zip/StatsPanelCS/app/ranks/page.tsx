import RanksClient from './RanksClient'

export const metadata = {
  title: 'Player Rankings',
  description: 'View player rankings and statistics',
}

export default function RanksPage() {
  return <RanksClient />
}
