'use client'

import { useState, useEffect } from 'react'
import { Card, CardBody, CardHeader } from '@nextui-org/card'
import { Table, TableHeader, TableColumn, TableBody, TableRow, TableCell } from '@nextui-org/table'
import { Pagination } from '@nextui-org/pagination'
import { Chip } from '@nextui-org/chip'
import { Spinner } from '@nextui-org/spinner'
import { Input } from '@nextui-org/input'
import { IconCoin, IconArrowLeft, IconSearch, IconTrophy } from '@tabler/icons-react'
import Link from 'next/link'
import useAuth from '@/utils/hooks/useAuth'

interface StorePlayer {
  position: number
  steamId: string
  name: string
  credits: number
  lastJoin: string
}

interface StoreStats {
  totalCredits: number
  avgCredits: number
  totalPlayers: number
  totalItems: number
  richestPlayer: {
    steamId: string
    name: string
    credits: number
  } | null
}

export default function StorePage() {
  const { user } = useAuth()
  const [players, setPlayers] = useState<StorePlayer[]>([])
  const [stats, setStats] = useState<StoreStats | null>(null)
  const [userCredits, setUserCredits] = useState<number | null>(null)
  const [page, setPage] = useState(1)
  const [total, setTotal] = useState(0)
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [searchResults, setSearchResults] = useState<StorePlayer[]>([])
  const [searching, setSearching] = useState(false)
  
  const limit = 20

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        // Fetch leaderboard
        const res = await fetch(`/api/store?action=leaderboard&page=${page}&limit=${limit}`)
        const data = await res.json()
        if (data.success) {
          setPlayers(data.data.players)
          setTotal(data.data.total)
        }

        // Fetch stats
        const statsRes = await fetch('/api/store?action=stats')
        const statsData = await statsRes.json()
        if (statsData.success) {
          setStats(statsData.data)
        }

        // Fetch user credits if logged in
        if (user?.id) {
          const userRes = await fetch(`/api/store?action=credits&steamid=${user.id}`)
          const userData = await userRes.json()
          if (userData.success) {
            setUserCredits(userData.data.credits)
          }
        }
      } catch (error) {
        console.error('Error:', error)
      }
      setLoading(false)
    }

    fetchData()
  }, [page, user])

  // Search
  useEffect(() => {
    const searchPlayers = async () => {
      if (search.length < 2) {
        setSearchResults([])
        return
      }
      setSearching(true)
      try {
        const res = await fetch(`/api/store?action=search&search=${encodeURIComponent(search)}`)
        const data = await res.json()
        if (data.success) {
          setSearchResults(data.data)
        }
      } catch (error) {
        console.error('Search error:', error)
      }
      setSearching(false)
    }

    const timer = setTimeout(searchPlayers, 300)
    return () => clearTimeout(timer)
  }, [search])

  const totalPages = Math.ceil(total / limit)

  const getMedal = (position: number) => {
    if (position === 1) return '🥇'
    if (position === 2) return '🥈'
    if (position === 3) return '🥉'
    return `#${position}`
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      {/* Header */}
      <div className="mb-8">
        <Link href="/" className="text-gray-400 hover:text-white mb-4 inline-flex items-center gap-2">
          <IconArrowLeft size={20} /> Back to Panel
        </Link>
        <div className="flex justify-between items-center mt-6">
          <div>
            <h1 className="text-4xl font-bold flex items-center gap-3">
              <IconCoin size={40} className="text-yellow-400" />
              Store Credits
            </h1>
            <p className="text-gray-400 mt-2">Leaderboard & Statistics</p>
          </div>
          {userCredits !== null && (
            <Card className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 border border-yellow-500/30">
              <CardBody className="flex flex-row items-center gap-3 py-3 px-6">
                <IconCoin size={24} className="text-yellow-400" />
                <div>
                  <p className="text-sm text-gray-400">Your Credits</p>
                  <p className="text-2xl font-bold text-yellow-400">
                    {userCredits.toLocaleString()}
                  </p>
                </div>
              </CardBody>
            </Card>
          )}
        </div>
      </div>

      {/* Stats Cards */}
      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Card className="bg-gradient-to-br from-yellow-500/20 to-yellow-600/10 border border-yellow-500/20">
            <CardBody className="text-center py-4">
              <p className="text-3xl font-bold text-yellow-400">{stats.totalCredits.toLocaleString()}</p>
              <p className="text-sm text-gray-400">Total Credits</p>
            </CardBody>
          </Card>
          <Card className="bg-gradient-to-br from-blue-500/20 to-blue-600/10 border border-blue-500/20">
            <CardBody className="text-center py-4">
              <p className="text-3xl font-bold text-blue-400">{stats.totalPlayers.toLocaleString()}</p>
              <p className="text-sm text-gray-400">Total Players</p>
            </CardBody>
          </Card>
          <Card className="bg-gradient-to-br from-green-500/20 to-green-600/10 border border-green-500/20">
            <CardBody className="text-center py-4">
              <p className="text-3xl font-bold text-green-400">{stats.avgCredits.toLocaleString()}</p>
              <p className="text-sm text-gray-400">Average Credits</p>
            </CardBody>
          </Card>
          <Card className="bg-gradient-to-br from-purple-500/20 to-purple-600/10 border border-purple-500/20">
            <CardBody className="text-center py-4">
              <p className="text-3xl font-bold text-purple-400">{stats.totalItems.toLocaleString()}</p>
              <p className="text-sm text-gray-400">Items Purchased</p>
            </CardBody>
          </Card>
        </div>
      )}

      {/* Richest Player */}
      {stats?.richestPlayer && (
        <Card className="mb-8 bg-gradient-to-r from-yellow-500/10 to-orange-500/10 border border-yellow-500/20">
          <CardBody className="flex flex-row items-center gap-6 py-6">
            <span className="text-6xl">👑</span>
            <div>
              <p className="text-sm text-gray-400">Richest Player</p>
              <p className="text-2xl font-bold">{stats.richestPlayer.name}</p>
              <p className="text-xl text-yellow-400 font-mono">
                {stats.richestPlayer.credits.toLocaleString()} credits
              </p>
            </div>
          </CardBody>
        </Card>
      )}

      {/* Search */}
      <div className="mb-6 relative">
        <Input
          placeholder="Search player by name..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          startContent={<IconSearch size={18} />}
          endContent={searching && <Spinner size="sm" />}
          classNames={{
            inputWrapper: 'bg-default-100',
          }}
        />
        {searchResults.length > 0 && (
          <Card className="absolute z-50 w-full mt-2 shadow-xl">
            <CardBody className="p-2">
              {searchResults.map((player) => (
                <Link key={player.steamId} href={`/player/${player.steamId}`}>
                  <div className="flex justify-between items-center p-3 hover:bg-default-100 rounded-lg cursor-pointer">
                    <span className="font-semibold">{player.name}</span>
                    <Chip color="warning" variant="flat" size="sm">
                      {player.credits.toLocaleString()} credits
                    </Chip>
                  </div>
                </Link>
              ))}
            </CardBody>
          </Card>
        )}
      </div>

      {/* Leaderboard */}
      <Card>
        <CardHeader>
          <h2 className="text-xl font-bold flex items-center gap-2">
            <IconTrophy size={24} className="text-yellow-400" />
            Credits Leaderboard
          </h2>
        </CardHeader>
        <CardBody>
          {loading ? (
            <div className="flex justify-center py-8">
              <Spinner size="lg" />
            </div>
          ) : (
            <>
              <Table aria-label="Store leaderboard">
                <TableHeader>
                  <TableColumn>RANK</TableColumn>
                  <TableColumn>PLAYER</TableColumn>
                  <TableColumn>CREDITS</TableColumn>
                  <TableColumn>LAST SEEN</TableColumn>
                </TableHeader>
                <TableBody items={players}>
                  {(player) => (
                    <TableRow key={player.steamId}>
                      <TableCell>
                        <span className={`font-bold ${player.position <= 3 ? 'text-xl' : ''}`}>
                          {getMedal(player.position)}
                        </span>
                      </TableCell>
                      <TableCell>
                        <Link href={`/player/${player.steamId}`} className="hover:text-primary">
                          {player.name}
                        </Link>
                      </TableCell>
                      <TableCell>
                        <span className="font-mono text-yellow-400">
                          {player.credits.toLocaleString()}
                        </span>
                      </TableCell>
                      <TableCell className="text-gray-400">
                        {new Date(player.lastJoin).toLocaleDateString()}
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>

              {totalPages > 1 && (
                <div className="flex justify-center mt-6">
                  <Pagination
                    total={totalPages}
                    page={page}
                    onChange={setPage}
                    color="primary"
                    showControls
                  />
                </div>
              )}
            </>
          )}
        </CardBody>
      </Card>

      {/* Info */}
      <div className="mt-6 text-center text-gray-500 text-sm">
        <p>💰 Earn credits by playing on the server</p>
        <p>🎮 Use <code className="bg-default-100 px-2 py-1 rounded">!store</code> in-game to open the shop</p>
      </div>
    </div>
  )
}
