'use client'

import { Card, CardBody, CardHeader } from '@nextui-org/card'
import { Input } from '@nextui-org/input'
import { Button } from '@nextui-org/button'
import { Switch } from '@nextui-org/switch'
import { useState } from 'react'
import { toast } from 'react-hot-toast'
import { IconBrandDiscord, IconTestPipe } from '@tabler/icons-react'

export default function DiscordSettings() {
  const [webhookUrl, setWebhookUrl] = useState('')
  const [notifications, setNotifications] = useState({
    bans: true,
    unbans: true,
    mutes: true,
    kicks: true,
    topPlayers: false,
    serverStatus: false,
  })
  const [testing, setTesting] = useState(false)

  const testWebhook = async () => {
    if (!webhookUrl) {
      toast.error('Please enter a webhook URL')
      return
    }

    setTesting(true)
    try {
      const response = await fetch(webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: 'CS2 Panel',
          embeds: [{
            title: '✅ Webhook Test Successful!',
            description: 'Your Discord webhook is configured correctly.',
            color: 0x00FF00,
            timestamp: new Date().toISOString(),
            footer: { text: 'ZewCS Panel' }
          }]
        })
      })

      if (response.ok) {
        toast.success('Test message sent! Check your Discord channel.')
      } else {
        toast.error('Failed to send test message. Check your webhook URL.')
      }
    } catch (error) {
      toast.error('Error sending test message')
    }
    setTesting(false)
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex items-center gap-2">
          <IconBrandDiscord size={24} className="text-[#5865F2]" />
          <span className="font-bold">Discord Webhook Settings</span>
        </CardHeader>
        <CardBody className="space-y-4">
          <div>
            <Input
              label="Webhook URL"
              placeholder="https://discord.com/api/webhooks/..."
              value={webhookUrl}
              onChange={(e) => setWebhookUrl(e.target.value)}
              description="Get this from your Discord server settings → Integrations → Webhooks"
            />
          </div>

          <div className="flex gap-2">
            <Button
              color="primary"
              variant="flat"
              onClick={testWebhook}
              isLoading={testing}
              startContent={<IconTestPipe size={18} />}
            >
              Test Webhook
            </Button>
          </div>
        </CardBody>
      </Card>

      <Card>
        <CardHeader>
          <span className="font-bold">Notification Settings</span>
        </CardHeader>
        <CardBody className="space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <p className="font-semibold">Ban Notifications</p>
              <p className="text-sm text-gray-400">Send notification when a player is banned</p>
            </div>
            <Switch
              isSelected={notifications.bans}
              onValueChange={(v) => setNotifications({ ...notifications, bans: v })}
              color="danger"
            />
          </div>

          <div className="flex justify-between items-center">
            <div>
              <p className="font-semibold">Unban Notifications</p>
              <p className="text-sm text-gray-400">Send notification when a player is unbanned</p>
            </div>
            <Switch
              isSelected={notifications.unbans}
              onValueChange={(v) => setNotifications({ ...notifications, unbans: v })}
              color="success"
            />
          </div>

          <div className="flex justify-between items-center">
            <div>
              <p className="font-semibold">Mute Notifications</p>
              <p className="text-sm text-gray-400">Send notification when a player is muted</p>
            </div>
            <Switch
              isSelected={notifications.mutes}
              onValueChange={(v) => setNotifications({ ...notifications, mutes: v })}
              color="warning"
            />
          </div>

          <div className="flex justify-between items-center">
            <div>
              <p className="font-semibold">Kick Notifications</p>
              <p className="text-sm text-gray-400">Send notification when a player is kicked</p>
            </div>
            <Switch
              isSelected={notifications.kicks}
              onValueChange={(v) => setNotifications({ ...notifications, kicks: v })}
              color="secondary"
            />
          </div>

          <div className="flex justify-between items-center">
            <div>
              <p className="font-semibold">Top Player Notifications</p>
              <p className="text-sm text-gray-400">Send notification when someone reaches top 10</p>
            </div>
            <Switch
              isSelected={notifications.topPlayers}
              onValueChange={(v) => setNotifications({ ...notifications, topPlayers: v })}
              color="primary"
            />
          </div>

          <div className="flex justify-between items-center">
            <div>
              <p className="font-semibold">Server Status Notifications</p>
              <p className="text-sm text-gray-400">Send notification when server goes online/offline</p>
            </div>
            <Switch
              isSelected={notifications.serverStatus}
              onValueChange={(v) => setNotifications({ ...notifications, serverStatus: v })}
              color="primary"
            />
          </div>
        </CardBody>
      </Card>

      <p className="text-sm text-gray-500 text-center">
        Note: These settings will be saved to the panel configuration.
        Make sure to click Save Changes at the bottom of the settings page.
      </p>
    </div>
  )
}
