'use client'

import { usePathname } from 'next/navigation'
import Link from 'next/link'
import { Flag } from '@/utils/types/db/css'

const AdminTabs = () => {
	const pathname = usePathname()

	return (
		<div className="flex flex-wrap gap-2 mb-4">
			{ADMIN_TABS.map((item) => (
				<Link
					key={item.path}
					href={item.path}
					className={`px-4 py-2 rounded-lg transition-all ${
						pathname === item.path
							? 'bg-primary text-white'
							: 'bg-default-100 hover:bg-default-200 text-default-600'
					}`}
				>
					{item.title}
				</Link>
			))}
		</div>
	)
}

export default AdminTabs

export const ADMIN_TABS: Tab[] = [
	{
		path: '/admin',
		title: 'Statistics',
		permissions: [],
	},
	{
		path: '/admin/admins',
		title: 'Manage Admins',
		permissions: ['@web/root', '@css/root', '@web/admins'],
	},
	{
		path: '/admin/servers',
		title: 'Manage Servers',
		permissions: ['@web/root', '@css/root', '@web/servers'],
	},
	{
		path: '/admin/bans',
		title: 'Manage Bans',
		permissions: ['@web/root', '@css/root', '@web/bans'],
	},
	{
		path: '/admin/mutes',
		title: 'Manage Mutes',
		permissions: ['@web/root', '@css/root', '@web/mutes'],
	},
	{
		path: '/admin/logs',
		title: 'Logs',
		permissions: ['@web/root', '@css/root', '@web/logs'],
	},
	{
		path: '/admin/modules',
		title: '🧩 Modules',
		permissions: ['@web/root', '@css/root'],
	},
	{
		path: '/admin/settings',
		title: 'Panel Settings',
		permissions: ['@web/root', '@css/root'],
	},
]

interface Tab {
	path: string
	title: string
	permissions: Flag[]
}
