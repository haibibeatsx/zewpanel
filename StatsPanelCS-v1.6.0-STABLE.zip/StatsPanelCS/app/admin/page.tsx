'use client'

import { Card, CardBody, CardHeader } from '@nextui-org/card'
import { Spinner } from '@nextui-org/spinner'
import { IconUsers, IconBan, IconMicrophone, IconServer, IconTrophy, IconActivity } from '@tabler/icons-react'
import useSWR from 'swr'
import fetcher from '@/utils/fetcher'
import Link from 'next/link'

interface Stats {
  totalPlayers?: number
  totalKills?: number
  totalDeaths?: number
  totalHeadshots?: number
  avgExperience?: number
}

const AdminDashboard = () => {
  const { data: rankStats, isLoading: loadingRanks } = useSWR<Stats>('/api/ranks?action=stats', fetcher)
  const { data: bans } = useSWR('/api/bans?page=1&rows=5', fetcher)
  const { data: mutes } = useSWR('/api/mutes?page=1&rows=5', fetcher)

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">📊 Dashboard Overview</h2>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-blue-500/20 to-blue-600/10 border border-blue-500/20">
          <CardBody className="flex flex-row items-center gap-4">
            <div className="p-3 bg-blue-500/20 rounded-lg">
              <IconUsers size={24} className="text-blue-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-blue-400">
                {loadingRanks ? <Spinner size="sm" /> : rankStats?.totalPlayers?.toLocaleString() || 0}
              </p>
              <p className="text-sm text-gray-400">Total Players</p>
            </div>
          </CardBody>
        </Card>

        <Card className="bg-gradient-to-br from-red-500/20 to-red-600/10 border border-red-500/20">
          <CardBody className="flex flex-row items-center gap-4">
            <div className="p-3 bg-red-500/20 rounded-lg">
              <IconBan size={24} className="text-red-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-red-400">
                {bans?.count?.toLocaleString() || 0}
              </p>
              <p className="text-sm text-gray-400">Total Bans</p>
            </div>
          </CardBody>
        </Card>

        <Card className="bg-gradient-to-br from-yellow-500/20 to-yellow-600/10 border border-yellow-500/20">
          <CardBody className="flex flex-row items-center gap-4">
            <div className="p-3 bg-yellow-500/20 rounded-lg">
              <IconMicrophone size={24} className="text-yellow-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-yellow-400">
                {mutes?.count?.toLocaleString() || 0}
              </p>
              <p className="text-sm text-gray-400">Total Mutes</p>
            </div>
          </CardBody>
        </Card>

        <Card className="bg-gradient-to-br from-green-500/20 to-green-600/10 border border-green-500/20">
          <CardBody className="flex flex-row items-center gap-4">
            <div className="p-3 bg-green-500/20 rounded-lg">
              <IconTrophy size={24} className="text-green-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-green-400">
                {loadingRanks ? <Spinner size="sm" /> : rankStats?.totalKills?.toLocaleString() || 0}
              </p>
              <p className="text-sm text-gray-400">Total Kills</p>
            </div>
          </CardBody>
        </Card>
      </div>

      {/* Activity Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader className="flex items-center gap-2">
            <IconActivity size={20} />
            <span className="font-bold">Player Statistics</span>
          </CardHeader>
          <CardBody className="space-y-3">
            <div className="flex justify-between items-center p-3 bg-default-100 rounded-lg">
              <span className="text-gray-400">Total Kills</span>
              <span className="font-bold text-green-400">{rankStats?.totalKills?.toLocaleString() || 0}</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-default-100 rounded-lg">
              <span className="text-gray-400">Total Deaths</span>
              <span className="font-bold text-red-400">{rankStats?.totalDeaths?.toLocaleString() || 0}</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-default-100 rounded-lg">
              <span className="text-gray-400">Total Headshots</span>
              <span className="font-bold text-yellow-400">{rankStats?.totalHeadshots?.toLocaleString() || 0}</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-default-100 rounded-lg">
              <span className="text-gray-400">Average XP</span>
              <span className="font-bold text-blue-400">{Math.round(rankStats?.avgExperience || 0).toLocaleString()}</span>
            </div>
          </CardBody>
        </Card>

        <Card>
          <CardHeader className="flex items-center gap-2">
            <IconBan size={20} />
            <span className="font-bold">Recent Bans</span>
          </CardHeader>
          <CardBody>
            {bans?.results?.length > 0 ? (
              <div className="space-y-2">
                {bans.results.slice(0, 5).map((ban: any) => (
                  <div key={ban.id} className="flex justify-between items-center p-2 bg-default-100 rounded-lg text-sm">
                    <div>
                      <p className="font-semibold">{ban.player_name || 'Unknown'}</p>
                      <p className="text-xs text-gray-400 truncate max-w-[150px]">{ban.reason || 'No reason'}</p>
                    </div>
                    <span className={`text-xs px-2 py-1 rounded ${ban.status === 'ACTIVE' ? 'bg-red-500/20 text-red-400' : 'bg-gray-500/20 text-gray-400'}`}>
                      {ban.status}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-400 text-center py-4">No recent bans</p>
            )}
          </CardBody>
        </Card>
      </div>

      {/* Quick Links */}
      <Card>
        <CardHeader>
          <span className="font-bold">⚡ Quick Actions</span>
        </CardHeader>
        <CardBody>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Link href="/admin/servers" className="p-4 bg-default-100 hover:bg-default-200 rounded-lg text-center transition-colors block">
              <IconServer size={32} className="mx-auto mb-2 text-blue-400" />
              <p className="font-semibold">Manage Servers</p>
            </Link>
            <Link href="/admin/admins" className="p-4 bg-default-100 hover:bg-default-200 rounded-lg text-center transition-colors block">
              <IconUsers size={32} className="mx-auto mb-2 text-green-400" />
              <p className="font-semibold">Manage Admins</p>
            </Link>
            <Link href="/admin/bans" className="p-4 bg-default-100 hover:bg-default-200 rounded-lg text-center transition-colors block">
              <IconBan size={32} className="mx-auto mb-2 text-red-400" />
              <p className="font-semibold">Manage Bans</p>
            </Link>
            <Link href="/admin/settings" className="p-4 bg-default-100 hover:bg-default-200 rounded-lg text-center transition-colors block">
              <IconActivity size={32} className="mx-auto mb-2 text-yellow-400" />
              <p className="font-semibold">Panel Settings</p>
            </Link>
          </div>
        </CardBody>
      </Card>
    </div>
  )
}

export default AdminDashboard
