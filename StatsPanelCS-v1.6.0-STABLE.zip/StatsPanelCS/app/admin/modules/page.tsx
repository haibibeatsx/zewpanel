'use client'

import { useState, useEffect } from 'react'
import { Card, CardBody, CardHeader } from '@nextui-org/card'
import { Switch } from '@nextui-org/switch'
import { Button } from '@nextui-org/button'
import { Spinner } from '@nextui-org/spinner'
import { 
	IconTrophy, 
	IconCoin, 
	IconDice, 
	IconCrown, 
	IconServer, 
	IconUsers,
	IconCheck,
	IconX
} from '@tabler/icons-react'
import toast from 'react-hot-toast'

interface ModuleConfig {
	id: string
	name: string
	description: string
	icon: React.ReactNode
	color: string
}

const MODULES: ModuleConfig[] = [
	{
		id: 'rankings',
		name: 'Rankings',
		description: 'Player rankings with XP, kills, deaths and achievements',
		icon: <IconTrophy size={24} />,
		color: 'text-yellow-400'
	},
	{
		id: 'store',
		name: 'Store Credits',
		description: 'Store credits leaderboard from CS2-Store plugin',
		icon: <IconCoin size={24} />,
		color: 'text-green-400'
	},
	{
		id: 'casino',
		name: 'Casino',
		description: 'Casino games (Coinflip, Roulette, Crash) with real credits',
		icon: <IconDice size={24} />,
		color: 'text-purple-400'
	},
	{
		id: 'vipShop',
		name: 'VIP Shop',
		description: 'VIP packages with Stripe payment integration',
		icon: <IconCrown size={24} />,
		color: 'text-orange-400'
	},
	{
		id: 'liveStatus',
		name: 'Live Server Status',
		description: 'Real-time server status on dashboard',
		icon: <IconServer size={24} />,
		color: 'text-blue-400'
	},
	{
		id: 'compare',
		name: 'Compare Players',
		description: 'Side-by-side player statistics comparison',
		icon: <IconUsers size={24} />,
		color: 'text-cyan-400'
	},
]

export default function ModulesPage() {
	const [modules, setModules] = useState<Record<string, boolean>>({})
	const [loading, setLoading] = useState(true)
	const [saving, setSaving] = useState(false)
	const [hasChanges, setHasChanges] = useState(false)
	const [originalModules, setOriginalModules] = useState<Record<string, boolean>>({})

	useEffect(() => {
		fetchModules()
	}, [])

	const fetchModules = async () => {
		try {
			const res = await fetch('/api/modules')
			const data = await res.json()
			if (data.success) {
				setModules(data.modules)
				setOriginalModules(data.modules)
			}
		} catch (error) {
			console.error('Error fetching modules:', error)
			toast.error('Failed to load module settings')
		}
		setLoading(false)
	}

	const toggleModule = (moduleId: string) => {
		const newModules = {
			...modules,
			[moduleId]: !modules[moduleId]
		}
		setModules(newModules)
		setHasChanges(JSON.stringify(newModules) !== JSON.stringify(originalModules))
	}

	const saveModules = async () => {
		setSaving(true)
		try {
			const res = await fetch('/api/modules', {
				method: 'PUT',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify({ modules })
			})
			const data = await res.json()
			
			if (data.success) {
				toast.success('Module settings saved!')
				setOriginalModules(modules)
				setHasChanges(false)
			} else {
				toast.error(data.error || 'Failed to save')
			}
		} catch (error) {
			toast.error('Failed to save module settings')
		}
		setSaving(false)
	}

	const resetChanges = () => {
		setModules(originalModules)
		setHasChanges(false)
	}

	if (loading) {
		return (
			<div className="flex justify-center items-center py-12">
				<Spinner size="lg" />
			</div>
		)
	}

	return (
		<div className="space-y-6">
			<div className="flex justify-between items-center">
				<div>
					<h1 className="text-2xl font-bold">🧩 Modules</h1>
					<p className="text-gray-400">Enable or disable panel features</p>
				</div>
				{hasChanges && (
					<div className="flex gap-2">
						<Button
							color="default"
							variant="flat"
							onClick={resetChanges}
						>
							Cancel
						</Button>
						<Button
							color="primary"
							onClick={saveModules}
							isLoading={saving}
						>
							Save Changes
						</Button>
					</div>
				)}
			</div>

			<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
				{MODULES.map((module) => (
					<Card 
						key={module.id}
						className={`transition-all ${
							modules[module.id] 
								? 'border-2 border-primary/50 bg-primary/5' 
								: 'border border-default-200 opacity-60'
						}`}
					>
						<CardBody className="p-4">
							<div className="flex items-start justify-between gap-4">
								<div className="flex items-start gap-3">
									<div className={`p-2 rounded-lg bg-default-100 ${module.color}`}>
										{module.icon}
									</div>
									<div>
										<h3 className="font-semibold flex items-center gap-2">
											{module.name}
											{modules[module.id] ? (
												<IconCheck size={16} className="text-green-400" />
											) : (
												<IconX size={16} className="text-red-400" />
											)}
										</h3>
										<p className="text-sm text-gray-400 mt-1">
											{module.description}
										</p>
									</div>
								</div>
								<Switch
									isSelected={modules[module.id]}
									onValueChange={() => toggleModule(module.id)}
									size="sm"
								/>
							</div>
						</CardBody>
					</Card>
				))}
			</div>

			<Card className="bg-blue-500/10 border border-blue-500/30">
				<CardBody>
					<h3 className="font-bold mb-2">💡 How it works</h3>
					<ul className="text-sm text-gray-400 space-y-1">
						<li>• Disabled modules will be hidden from the sidebar navigation</li>
						<li>• Users cannot access disabled module pages directly</li>
						<li>• Module data is preserved when disabled (not deleted)</li>
						<li>• Changes take effect after saving</li>
					</ul>
				</CardBody>
			</Card>

			<Card className="bg-orange-500/10 border border-orange-500/30">
				<CardBody>
					<h3 className="font-bold mb-2">⚠️ Requirements</h3>
					<div className="text-sm text-gray-400 space-y-2">
						<p><strong>Rankings:</strong> Requires RanksCore database connection</p>
						<p><strong>Store/Casino:</strong> Requires CS2-Store database connection</p>
						<p><strong>VIP Shop:</strong> Requires Stripe API keys for payments</p>
					</div>
				</CardBody>
			</Card>
		</div>
	)
}
