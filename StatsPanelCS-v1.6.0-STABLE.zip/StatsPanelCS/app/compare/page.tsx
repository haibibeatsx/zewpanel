'use client'

import { useState, useEffect } from 'react'
import { Card, CardBody, CardHeader } from '@nextui-org/card'
import { Input } from '@nextui-org/input'
import { Button } from '@nextui-org/button'
import { Chip } from '@nextui-org/chip'
import { Spinner } from '@nextui-org/spinner'
import { Progress } from '@nextui-org/progress'
import { IconArrowLeft, IconSearch, IconVs } from '@tabler/icons-react'
import Link from 'next/link'

interface PlayerData {
  position: number
  steamId: string
  name: string
  experience: number
  rank: string
  kills: number
  deaths: number
  assists: number
  kd: number
  headshots: number
  hsPercent: number
  accuracy: number
  roundsWon: number
  roundsLost: number
  winRate: number
  playtime: number
}

interface SearchResult {
  steamId: string
  name: string
  experience: number
  rank: string
}

const getRankColor = (rankName: string): 'default' | 'primary' | 'secondary' | 'success' | 'warning' | 'danger' => {
  if (rankName.includes('Silver')) return 'default'
  if (rankName.includes('Gold')) return 'warning'
  if (rankName.includes('Master Guardian') || rankName.includes('Distinguished')) return 'primary'
  if (rankName.includes('Legendary') || rankName.includes('Supreme')) return 'secondary'
  if (rankName.includes('Global')) return 'danger'
  return 'default'
}

const formatPlaytime = (minutes: number) => {
  if (!minutes) return '0h'
  const hours = Math.floor(minutes / 60)
  return `${hours}h`
}

const StatComparison = ({ 
  label, 
  value1, 
  value2, 
  format = 'number',
  higherIsBetter = true 
}: { 
  label: string
  value1: number
  value2: number
  format?: 'number' | 'percent' | 'decimal'
  higherIsBetter?: boolean
}) => {
  const formatValue = (v: number) => {
    if (format === 'percent') return `${v}%`
    if (format === 'decimal') return v.toFixed(2)
    return v.toLocaleString()
  }

  const winner = higherIsBetter 
    ? (value1 > value2 ? 1 : value1 < value2 ? 2 : 0)
    : (value1 < value2 ? 1 : value1 > value2 ? 2 : 0)

  return (
    <div className="grid grid-cols-3 gap-4 py-3 border-b border-default-100">
      <div className={`text-right font-bold ${winner === 1 ? 'text-green-400' : ''}`}>
        {formatValue(value1)}
        {winner === 1 && ' 👑'}
      </div>
      <div className="text-center text-gray-400 text-sm">{label}</div>
      <div className={`text-left font-bold ${winner === 2 ? 'text-green-400' : ''}`}>
        {winner === 2 && '👑 '}
        {formatValue(value2)}
      </div>
    </div>
  )
}

export default function ComparePage() {
  const [search1, setSearch1] = useState('')
  const [search2, setSearch2] = useState('')
  const [results1, setResults1] = useState<SearchResult[]>([])
  const [results2, setResults2] = useState<SearchResult[]>([])
  const [player1, setPlayer1] = useState<PlayerData | null>(null)
  const [player2, setPlayer2] = useState<PlayerData | null>(null)
  const [loading1, setLoading1] = useState(false)
  const [loading2, setLoading2] = useState(false)

  const searchPlayer = async (query: string, setResults: (r: SearchResult[]) => void) => {
    if (query.length < 2) {
      setResults([])
      return
    }
    try {
      const res = await fetch(`/api/ranks?action=search&search=${encodeURIComponent(query)}`)
      const data = await res.json()
      if (data.success) setResults(data.data)
    } catch (error) {
      console.error('Search error:', error)
    }
  }

  const selectPlayer = async (steamId: string, setPlayer: (p: PlayerData | null) => void, setLoading: (l: boolean) => void) => {
    setLoading(true)
    try {
      const res = await fetch(`/api/ranks?action=player&steamid=${steamId}`)
      const data = await res.json()
      if (data.success) setPlayer(data.data)
    } catch (error) {
      console.error('Error:', error)
    }
    setLoading(false)
  }

  useEffect(() => {
    const timer = setTimeout(() => searchPlayer(search1, setResults1), 300)
    return () => clearTimeout(timer)
  }, [search1])

  useEffect(() => {
    const timer = setTimeout(() => searchPlayer(search2, setResults2), 300)
    return () => clearTimeout(timer)
  }, [search2])

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <Link href="/ranks" className="inline-flex items-center gap-2 text-gray-400 hover:text-white mb-6">
        <IconArrowLeft size={20} /> Back to Rankings
      </Link>

      <h1 className="text-3xl font-bold mb-8 flex items-center gap-3">
        <IconVs size={32} /> Compare Players
      </h1>

      {/* Player Selection */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
        {/* Player 1 */}
        <Card>
          <CardHeader>Player 1</CardHeader>
          <CardBody>
            {player1 ? (
              <div className="text-center">
                <h3 className="text-xl font-bold mb-2">{player1.name}</h3>
                <Chip color={getRankColor(player1.rank)} variant="shadow" className="mb-2">
                  {player1.rank}
                </Chip>
                <p className="text-sm text-gray-400">#{player1.position} • {player1.experience.toLocaleString()} XP</p>
                <Button 
                  size="sm" 
                  variant="flat" 
                  className="mt-4"
                  onClick={() => setPlayer1(null)}
                >
                  Change
                </Button>
              </div>
            ) : (
              <div className="relative">
                <Input
                  placeholder="Search player..."
                  value={search1}
                  onChange={(e) => setSearch1(e.target.value)}
                  startContent={<IconSearch size={18} />}
                />
                {results1.length > 0 && (
                  <div className="absolute z-10 w-full mt-2 bg-default-100 rounded-lg shadow-xl max-h-60 overflow-auto">
                    {results1.map(p => (
                      <div
                        key={p.steamId}
                        className="p-3 hover:bg-default-200 cursor-pointer"
                        onClick={() => {
                          selectPlayer(p.steamId, setPlayer1, setLoading1)
                          setSearch1('')
                          setResults1([])
                        }}
                      >
                        <p className="font-semibold">{p.name}</p>
                        <p className="text-xs text-gray-400">{p.rank}</p>
                      </div>
                    ))}
                  </div>
                )}
                {loading1 && <Spinner size="sm" className="mt-4" />}
              </div>
            )}
          </CardBody>
        </Card>

        {/* Player 2 */}
        <Card>
          <CardHeader>Player 2</CardHeader>
          <CardBody>
            {player2 ? (
              <div className="text-center">
                <h3 className="text-xl font-bold mb-2">{player2.name}</h3>
                <Chip color={getRankColor(player2.rank)} variant="shadow" className="mb-2">
                  {player2.rank}
                </Chip>
                <p className="text-sm text-gray-400">#{player2.position} • {player2.experience.toLocaleString()} XP</p>
                <Button 
                  size="sm" 
                  variant="flat" 
                  className="mt-4"
                  onClick={() => setPlayer2(null)}
                >
                  Change
                </Button>
              </div>
            ) : (
              <div className="relative">
                <Input
                  placeholder="Search player..."
                  value={search2}
                  onChange={(e) => setSearch2(e.target.value)}
                  startContent={<IconSearch size={18} />}
                />
                {results2.length > 0 && (
                  <div className="absolute z-10 w-full mt-2 bg-default-100 rounded-lg shadow-xl max-h-60 overflow-auto">
                    {results2.map(p => (
                      <div
                        key={p.steamId}
                        className="p-3 hover:bg-default-200 cursor-pointer"
                        onClick={() => {
                          selectPlayer(p.steamId, setPlayer2, setLoading2)
                          setSearch2('')
                          setResults2([])
                        }}
                      >
                        <p className="font-semibold">{p.name}</p>
                        <p className="text-xs text-gray-400">{p.rank}</p>
                      </div>
                    ))}
                  </div>
                )}
                {loading2 && <Spinner size="sm" className="mt-4" />}
              </div>
            )}
          </CardBody>
        </Card>
      </div>

      {/* Comparison */}
      {player1 && player2 && (
        <Card>
          <CardHeader className="justify-center">
            <h2 className="text-xl font-bold">
              {player1.name} vs {player2.name}
            </h2>
          </CardHeader>
          <CardBody>
            <StatComparison label="Position" value1={player1.position} value2={player2.position} higherIsBetter={false} />
            <StatComparison label="Experience" value1={player1.experience} value2={player2.experience} />
            <StatComparison label="Kills" value1={player1.kills} value2={player2.kills} />
            <StatComparison label="Deaths" value1={player1.deaths} value2={player2.deaths} higherIsBetter={false} />
            <StatComparison label="K/D Ratio" value1={player1.kd} value2={player2.kd} format="decimal" />
            <StatComparison label="Headshots" value1={player1.headshots} value2={player2.headshots} />
            <StatComparison label="HS %" value1={player1.hsPercent} value2={player2.hsPercent} format="percent" />
            <StatComparison label="Accuracy" value1={player1.accuracy} value2={player2.accuracy} format="percent" />
            <StatComparison label="Assists" value1={player1.assists} value2={player2.assists} />
            <StatComparison label="Rounds Won" value1={player1.roundsWon} value2={player2.roundsWon} />
            <StatComparison label="Win Rate" value1={parseFloat(String(player1.winRate))} value2={parseFloat(String(player2.winRate))} format="percent" />
            <StatComparison label="Playtime" value1={player1.playtime} value2={player2.playtime} />
          </CardBody>
        </Card>
      )}

      {(!player1 || !player2) && (
        <Card className="bg-default-100/50">
          <CardBody className="text-center py-12 text-gray-400">
            Select two players to compare their stats
          </CardBody>
        </Card>
      )}
    </div>
  )
}
