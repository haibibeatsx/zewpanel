'use client'

import { useState, useEffect } from 'react'
import { Card, CardBody, CardHeader } from '@nextui-org/card'
import { Chip } from '@nextui-org/chip'
import { Spinner } from '@nextui-org/spinner'
import Link from 'next/link'

interface TopPlayer {
  position: number
  steamId: string
  name: string
  experience: number
  rank: string
  kills: number
  kd: number
  hsPercent: number
}

const getRankColor = (rankName: string): 'default' | 'primary' | 'secondary' | 'success' | 'warning' | 'danger' => {
  if (rankName.includes('Silver')) return 'default'
  if (rankName.includes('Gold')) return 'warning'
  if (rankName.includes('Master Guardian') || rankName.includes('Distinguished')) return 'primary'
  if (rankName.includes('Legendary') || rankName.includes('Supreme')) return 'secondary'
  if (rankName.includes('Global')) return 'danger'
  return 'default'
}

const getMedal = (position: number) => {
  switch (position) {
    case 1: return '🥇'
    case 2: return '🥈'
    case 3: return '🥉'
    case 4: return '4️⃣'
    case 5: return '5️⃣'
    default: return `#${position}`
  }
}

export default function TopPlayers() {
  const [players, setPlayers] = useState<TopPlayer[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchTopPlayers = async () => {
      try {
        const res = await fetch('/api/ranks?action=leaderboard&page=1&limit=5')
        const data = await res.json()
        if (data.success) {
          setPlayers(data.data.players)
        }
      } catch (error) {
        console.error('Error fetching top players:', error)
      }
      setLoading(false)
    }
    fetchTopPlayers()
  }, [])

  if (loading) {
    return (
      <Card className="bg-gradient-to-br from-yellow-500/10 to-orange-500/10 border border-yellow-500/20">
        <CardBody className="flex justify-center items-center py-8">
          <Spinner color="warning" />
        </CardBody>
      </Card>
    )
  }

  return (
    <Card className="bg-gradient-to-br from-yellow-500/10 to-orange-500/10 border border-yellow-500/20">
      <CardHeader className="flex justify-between items-center">
        <h3 className="text-xl font-bold flex items-center gap-2">
          🏆 Top 5 Players
        </h3>
        <Link 
          href="/ranks" 
          className="text-sm text-primary hover:underline"
        >
          View All →
        </Link>
      </CardHeader>
      <CardBody className="gap-2">
        {players.map((player, index) => (
          <Link 
            key={player.steamId} 
            href={`/player/${player.steamId}`}
            className="block"
          >
            <div 
              className={`flex items-center justify-between p-3 rounded-lg transition-all hover:scale-[1.02] cursor-pointer ${
                index === 0 
                  ? 'bg-gradient-to-r from-yellow-500/20 to-yellow-600/10 border border-yellow-500/30' 
                  : 'bg-default-100/50 hover:bg-default-200/50'
              }`}
            >
              <div className="flex items-center gap-3">
                <span className="text-2xl w-10 text-center">{getMedal(player.position)}</span>
                <div>
                  <p className={`font-semibold ${index === 0 ? 'text-yellow-400' : ''}`}>
                    {player.name}
                  </p>
                  <p className="text-xs text-gray-400">
                    {player.kills.toLocaleString()} kills • {player.kd} K/D • {player.hsPercent}% HS
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Chip 
                  color={getRankColor(player.rank)} 
                  size="sm" 
                  variant="flat"
                >
                  {player.rank}
                </Chip>
                <span className="text-sm font-mono text-blue-400">
                  {player.experience.toLocaleString()} XP
                </span>
              </div>
            </div>
          </Link>
        ))}
      </CardBody>
    </Card>
  )
}
