'use client'

import { useState, useEffect } from 'react'
import { Card, CardBody } from '@nextui-org/card'
import { Chip } from '@nextui-org/chip'
import { Spinner } from '@nextui-org/spinner'
import { IconUsers, IconMap, IconServer, IconRefresh } from '@tabler/icons-react'

interface ServerStatus {
  id: number
  hostname: string
  address: string
  players: number
  maxPlayers: number
  map: string
  online: boolean
}

interface ServerFromDB {
  id: number
  hostname: string
  address: string
}

interface ServerQueryResult {
  online: boolean
  info?: {
    name: string
    map: string
    players: number
    maxPlayers: number
  }
}

export default function LiveServerStats() {
  const [servers, setServers] = useState<ServerStatus[]>([])
  const [loading, setLoading] = useState(true)
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date())

  const fetchServers = async () => {
    try {
      // First get server list from DB
      const listRes = await fetch('/api/servers/list')
      const serverList: ServerFromDB[] = await listRes.json()
      
      if (!Array.isArray(serverList)) {
        setServers([])
        setLoading(false)
        return
      }

      // Then query each server for live status
      const serverStatuses: ServerStatus[] = await Promise.all(
        serverList.map(async (server) => {
          try {
            const queryRes = await fetch(`/api/servers/${server.id}`)
            const data = await queryRes.json()
            
            // Handle the response - server info is at root level when online
            if (data.online) {
              const playersCount = Array.isArray(data.players) ? data.players.length : (data.players || 0)
              return {
                id: server.id,
                hostname: data.hostname || server.hostname,
                address: data.address || server.address,
                players: playersCount,
                maxPlayers: data.maxPlayers || 0,
                map: data.map || '',
                online: true
              }
            } else {
              return {
                id: server.id,
                hostname: data.hostname || server.hostname,
                address: server.address,
                players: 0,
                maxPlayers: 0,
                map: '',
                online: false
              }
            }
          } catch {
            return {
              id: server.id,
              hostname: server.hostname,
              address: server.address,
              players: 0,
              maxPlayers: 0,
              map: '',
              online: false
            }
          }
        })
      )

      setServers(serverStatuses)
      setLastUpdate(new Date())
    } catch (error) {
      console.error('Error fetching servers:', error)
    }
    setLoading(false)
  }

  useEffect(() => {
    fetchServers()
    // Auto-refresh every 30 seconds
    const interval = setInterval(fetchServers, 30000)
    return () => clearInterval(interval)
  }, [])

  const totalPlayers = servers.reduce((acc, s) => acc + (s.players || 0), 0)
  const totalMaxPlayers = servers.reduce((acc, s) => acc + (s.maxPlayers || 0), 0)
  const onlineServers = servers.filter(s => s.online).length

  if (loading) {
    return (
      <Card className="bg-gradient-to-br from-blue-500/10 to-cyan-500/10 border border-blue-500/20">
        <CardBody className="flex justify-center items-center py-8">
          <Spinner color="primary" />
        </CardBody>
      </Card>
    )
  }

  return (
    <Card className="bg-gradient-to-br from-blue-500/10 to-cyan-500/10 border border-blue-500/20">
      <CardBody>
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-bold flex items-center gap-2">
            <IconServer size={24} className="text-blue-400" />
            Live Server Status
          </h3>
          <button 
            onClick={fetchServers}
            className="p-2 hover:bg-default-100 rounded-lg transition-colors"
            title="Refresh"
          >
            <IconRefresh size={18} className="text-gray-400" />
          </button>
        </div>

        {/* Summary */}
        <div className="grid grid-cols-3 gap-4 mb-4">
          <div className="text-center p-3 bg-default-100/50 rounded-lg">
            <div className="flex items-center justify-center gap-2 mb-1">
              <IconServer size={18} className="text-green-400" />
              <span className="text-2xl font-bold text-green-400">{onlineServers}</span>
            </div>
            <p className="text-xs text-gray-400">Servers Online</p>
          </div>
          <div className="text-center p-3 bg-default-100/50 rounded-lg">
            <div className="flex items-center justify-center gap-2 mb-1">
              <IconUsers size={18} className="text-blue-400" />
              <span className="text-2xl font-bold text-blue-400">{totalPlayers}</span>
            </div>
            <p className="text-xs text-gray-400">Players Online</p>
          </div>
          <div className="text-center p-3 bg-default-100/50 rounded-lg">
            <div className="flex items-center justify-center gap-2 mb-1">
              <IconUsers size={18} className="text-gray-400" />
              <span className="text-2xl font-bold">{totalMaxPlayers}</span>
            </div>
            <p className="text-xs text-gray-400">Total Slots</p>
          </div>
        </div>

        {/* Server List */}
        <div className="space-y-2">
          {servers.map(server => (
            <div 
              key={server.id}
              className={`flex items-center justify-between p-3 rounded-lg ${
                server.online ? 'bg-default-100/50' : 'bg-red-500/10'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className={`w-2 h-2 rounded-full ${server.online ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`} />
                <div>
                  <p className="font-semibold text-sm">{server.hostname || server.address}</p>
                  {server.online && server.map && (
                    <p className="text-xs text-gray-400 flex items-center gap-1">
                      <IconMap size={12} />
                      {server.map}
                    </p>
                  )}
                </div>
              </div>
              {server.online ? (
                <Chip 
                  size="sm" 
                  variant="flat"
                  color={server.players > 0 ? 'success' : 'default'}
                >
                  {server.players}/{server.maxPlayers}
                </Chip>
              ) : (
                <Chip size="sm" variant="flat" color="danger">Offline</Chip>
              )}
            </div>
          ))}
          
          {servers.length === 0 && (
            <p className="text-center text-gray-400 py-4">No servers configured</p>
          )}
        </div>

        <p className="text-xs text-gray-500 mt-4 text-center">
          Last updated: {lastUpdate.toLocaleTimeString()}
        </p>
      </CardBody>
    </Card>
  )
}
