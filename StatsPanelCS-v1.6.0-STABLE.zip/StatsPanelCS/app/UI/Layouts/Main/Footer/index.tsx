import Link from 'next/link'

const Footer = () => {
	return (
		<footer className='w-full flex items-center justify-center py-3 bg-slate-500/5'>
			<span className='flex items-center gap-1 text-current'>
				<span className='text-default-600'>Powered by</span>
				<p className='text-primary'>StatsPanelCS by ElProfessor</p>
			</span>
		</footer>
	)
}

export default Footer
