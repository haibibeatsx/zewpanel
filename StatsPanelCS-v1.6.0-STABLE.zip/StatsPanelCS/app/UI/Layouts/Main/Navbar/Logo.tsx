import query from '@/utils/functions/db'
import isUrl from '@/utils/functions/isURL'
import Image from 'next/image'

export const dynamic = 'force-dynamic'

const Logo = async () => {
	const logo = await query.settings.getByKey('logo')

	if (isUrl(logo || ''))
		return (
			<Image
				src={logo || ''}
				alt='Logo'
				width={120}
				height={40}
				className='h-10 w-auto'
				unoptimized
			/>
		)

	const title = await query.settings.getByKey('title')

	return <div className='text-xl font-bold'>{title}</div>
}

export default Logo
