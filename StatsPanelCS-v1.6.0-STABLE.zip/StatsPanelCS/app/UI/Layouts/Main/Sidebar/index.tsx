'use client'

import { useState, useEffect } from 'react'
import ROUTES from './Routes'
import Item from './Item'
import useAuth from '@/utils/hooks/useAuth'

interface ModulesState {
	rankings: boolean
	store: boolean
	casino: boolean
	vipShop: boolean
	liveStatus: boolean
	compare: boolean
}

const Sidebar = () => {
	const { admin } = useAuth()
	const [modules, setModules] = useState<ModulesState>({
		rankings: true,
		store: true,
		casino: true,
		vipShop: true,
		liveStatus: true,
		compare: true,
	})

	useEffect(() => {
		// Fetch module settings
		const fetchModules = async () => {
			try {
				const res = await fetch('/api/modules')
				const data = await res.json()
				if (data.success && data.modules) {
					setModules(data.modules)
				}
			} catch (error) {
				console.error('Error fetching modules:', error)
			}
		}
		fetchModules()
	}, [])

	return (
		<div className='flex flex-col min-w-[200px] pt-10'>
			{ROUTES.map((route) => {
				// Check if module is disabled
				if (route.moduleKey) {
					const moduleEnabled = modules[route.moduleKey as keyof ModulesState]
					if (!moduleEnabled) return null
				}

				if (route.admin) {
					if (!admin) return null

					if (route.flag) {
						const routeFlag = route.flag
						const adminFlags = admin.flags

						if (!adminFlags.includes(routeFlag)) return null
					}
				}

				return (
					<Item
						{...route}
						key={route.name}
					/>
				)
			})}
		</div>
	)
}

export default Sidebar
