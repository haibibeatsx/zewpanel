import { Flag } from '@/utils/types/db/css'
import { IconBan, IconDashboard, IconMicrophone, IconServer, IconTrophy, IconVs, IconBroadcast, IconCrown, IconDice, IconCoin, type Icon } from '@tabler/icons-react'

const ROUTES: Route[] = [
	{
		name: 'Dashboard',
		path: '/',
		icon: IconDashboard,
	},
	{
		name: 'Servers',
		path: '/servers',
		icon: IconServer,
	},
	{
		name: 'Rankings',
		path: '/ranks',
		icon: IconTrophy,
		moduleKey: 'rankings',
	},
	{
		name: 'Compare',
		path: '/compare',
		icon: IconVs,
		moduleKey: 'compare',
	},
	{
		name: 'Store',
		path: '/store',
		icon: IconCoin,
		moduleKey: 'store',
	},
	{
		name: 'Live',
		path: '/live',
		icon: IconBroadcast,
		moduleKey: 'liveStatus',
	},
	{
		name: 'Casino',
		path: '/casino',
		icon: IconDice,
		moduleKey: 'casino',
	},
	{
		name: 'VIP Shop',
		path: '/vip',
		icon: IconCrown,
		moduleKey: 'vipShop',
	},
	{
		name: 'Bans',
		path: '/bans',
		icon: IconBan,
	},
	{
		name: 'Mutes / Gags',
		path: '/mutes',
		icon: IconMicrophone,
	},
	{
		name: 'Admin Panel',
		path: '/admin',
		icon: IconServer,
		admin: true,
	},
]

export interface Route {
	path: string
	name: string
	icon: Icon
	admin?: boolean
	flag?: Flag
	moduleKey?: string
}

export default ROUTES
