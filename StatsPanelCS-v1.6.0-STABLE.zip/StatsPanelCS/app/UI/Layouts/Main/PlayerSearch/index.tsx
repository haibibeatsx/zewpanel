'use client'

import { useState, useEffect, useRef } from 'react'
import { Input } from '@nextui-org/input'
import { Card, CardBody } from '@nextui-org/card'
import { Chip } from '@nextui-org/chip'
import { Spinner } from '@nextui-org/spinner'
import { IconSearch } from '@tabler/icons-react'
import Link from 'next/link'

interface SearchPlayer {
  steamId: string
  name: string
  experience: number
  rank: string
  kills: number
  deaths: number
}

const getRankColor = (rankName: string): 'default' | 'primary' | 'secondary' | 'success' | 'warning' | 'danger' => {
  if (rankName.includes('Silver')) return 'default'
  if (rankName.includes('Gold')) return 'warning'
  if (rankName.includes('Master Guardian') || rankName.includes('Distinguished')) return 'primary'
  if (rankName.includes('Legendary') || rankName.includes('Supreme')) return 'secondary'
  if (rankName.includes('Global')) return 'danger'
  return 'default'
}

export default function PlayerSearch() {
  const [search, setSearch] = useState('')
  const [results, setResults] = useState<SearchPlayer[]>([])
  const [loading, setLoading] = useState(false)
  const [showResults, setShowResults] = useState(false)
  const wrapperRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
        setShowResults(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  useEffect(() => {
    const searchPlayers = async () => {
      if (search.length < 2) {
        setResults([])
        return
      }
      setLoading(true)
      try {
        const res = await fetch(`/api/ranks?action=search&search=${encodeURIComponent(search)}`)
        const data = await res.json()
        if (data.success) {
          setResults(data.data)
          setShowResults(true)
        }
      } catch (error) {
        console.error('Error searching:', error)
      }
      setLoading(false)
    }

    const timer = setTimeout(searchPlayers, 300)
    return () => clearTimeout(timer)
  }, [search])

  return (
    <div ref={wrapperRef} className="relative w-full max-w-md">
      <Input
        placeholder="Search player..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        onFocus={() => results.length > 0 && setShowResults(true)}
        startContent={<IconSearch size={18} className="text-gray-400" />}
        endContent={loading && <Spinner size="sm" />}
        classNames={{
          input: 'bg-transparent',
          inputWrapper: 'bg-default-100/50 border border-default-200',
        }}
      />
      
      {showResults && results.length > 0 && (
        <Card className="absolute z-50 w-full mt-2 max-h-80 overflow-auto shadow-xl">
          <CardBody className="p-2 gap-1">
            {results.map((player) => (
              <Link
                key={player.steamId}
                href={`/player/${player.steamId}`}
                onClick={() => {
                  setShowResults(false)
                  setSearch('')
                }}
              >
                <div className="flex items-center justify-between p-3 hover:bg-default-100 rounded-lg cursor-pointer transition-colors">
                  <div>
                    <p className="font-semibold">{player.name}</p>
                    <p className="text-xs text-gray-400">
                      {player.kills.toLocaleString()} kills • {player.experience.toLocaleString()} XP
                    </p>
                  </div>
                  <Chip color={getRankColor(player.rank)} size="sm" variant="flat">
                    {player.rank}
                  </Chip>
                </div>
              </Link>
            ))}
          </CardBody>
        </Card>
      )}
      
      {showResults && search.length >= 2 && results.length === 0 && !loading && (
        <Card className="absolute z-50 w-full mt-2 shadow-xl">
          <CardBody className="p-4 text-center text-gray-400">
            No players found
          </CardBody>
        </Card>
      )}
    </div>
  )
}
