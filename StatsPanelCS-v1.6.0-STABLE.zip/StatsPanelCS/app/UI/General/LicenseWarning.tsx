'use client'

import { useLicense } from '@/utils/hooks/useLicense'

export default function LicenseWarning() {
  const { status, loading } = useLicense()

  if (loading || status?.valid) return null

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-red-600 text-white py-2 px-4 text-center z-50">
      {status?.trial && (
        <span>
          ⚠️ Unlicensed copy of StatsPanelCS - Please purchase a license at{' '}
          <a href="https://elprofessor.dev" className="underline font-bold">
            elprofessor.dev
          </a>
        </span>
      )}
      {status?.expired && (
        <span>
          ⚠️ License expired - Please renew at{' '}
          <a href="https://elprofessor.dev" className="underline font-bold">
            elprofessor.dev
          </a>
        </span>
      )}
      {!status?.trial && !status?.expired && status?.error && (
        <span>⚠️ License error: {status.error}</span>
      )}
    </div>
  )
}
