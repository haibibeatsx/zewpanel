'use client'

import { useState, useEffect, useRef } from 'react'
import { Card, CardBody, CardHeader } from '@nextui-org/card'
import { Button } from '@nextui-org/button'
import { Input } from '@nextui-org/input'
import { Chip } from '@nextui-org/chip'
import { Spinner } from '@nextui-org/spinner'
import { IconSend, IconMessageCircle, IconUsers, IconMap, IconSwords } from '@tabler/icons-react'
import Link from 'next/link'

interface ChatMessage {
  id: number
  playerName: string
  message: string
  timestamp: string
  team?: string
}

interface ServerInfo {
  hostname: string
  map: string
  players: number
  maxPlayers: number
  online: boolean
}

export default function LivePage() {
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [newMessage, setNewMessage] = useState('')
  const [serverInfo, setServerInfo] = useState<ServerInfo | null>(null)
  const [loading, setLoading] = useState(true)
  const [connected, setConnected] = useState(false)
  const chatEndRef = useRef<HTMLDivElement>(null)

  // VIP Features
  const vipFeatures = [
    { name: 'Anti Flash', icon: '💡', desc: 'Reduced flash effect' },
    { name: 'Armor', icon: '🛡️', desc: 'Spawn with armor' },
    { name: 'Bhop', icon: '🐰', desc: 'Auto bunny hop' },
    { name: 'Fast Defuse', icon: '💣', desc: 'Faster bomb defuse' },
    { name: 'Extra Damage', icon: '💪', desc: 'Deal more damage' },
    { name: 'Decoy Teleport', icon: '🎭', desc: 'Teleport to decoy' },
  ]

  useEffect(() => {
    // Fetch server info
    const fetchData = async () => {
      try {
        const res = await fetch('/api/servers/list')
        const data = await res.json()
        if (data && data.length > 0) {
          setServerInfo(data[0])
          setConnected(true)
        }
      } catch (error) {
        console.error('Error:', error)
      }
      setLoading(false)
    }

    fetchData()
    const interval = setInterval(fetchData, 15000) // Refresh every 15s
    return () => clearInterval(interval)
  }, [])

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const sendMessage = async () => {
    if (!newMessage.trim()) return
    // This would send to Discord relay
    setNewMessage('')
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Spinner size="lg" />
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      {/* Header */}
      <div className="mb-8">
        <Link href="/" className="text-gray-400 hover:text-white mb-4 inline-block">
          ← Back to Panel
        </Link>
        <h1 className="text-4xl font-bold flex items-center gap-3">
          🎮 Live Server
          {connected && (
            <Chip color="success" variant="dot" size="sm">Connected</Chip>
          )}
        </h1>
        <p className="text-gray-400 mt-2">Real-time server information and features</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content - 2 columns */}
        <div className="lg:col-span-2 space-y-6">
          {/* Server Status Card */}
          <Card className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 border border-blue-500/30">
            <CardBody>
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-2xl font-bold">{serverInfo?.hostname || 'Server'}</h2>
                  <div className="flex items-center gap-4 mt-2 text-gray-400">
                    <span className="flex items-center gap-1">
                      <IconMap size={18} />
                      {serverInfo?.map || 'Unknown'}
                    </span>
                    <span className="flex items-center gap-1">
                      <IconUsers size={18} />
                      {serverInfo?.players || 0}/{serverInfo?.maxPlayers || 0}
                    </span>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    color="primary"
                    as={Link}
                    href={`steam://connect/${serverInfo?.hostname ? '51.195.117.14:27015' : ''}`}
                  >
                    🎮 Connect
                  </Button>
                </div>
              </div>
            </CardBody>
          </Card>

          {/* Team Bet Section */}
          <Card className="bg-gradient-to-r from-orange-500/10 to-red-500/10 border border-orange-500/20">
            <CardHeader>
              <h3 className="text-xl font-bold flex items-center gap-2">
                <IconSwords size={24} className="text-orange-400" />
                Team Betting
              </h3>
            </CardHeader>
            <CardBody>
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-6 bg-blue-500/20 rounded-lg border border-blue-500/30">
                  <p className="text-4xl font-bold text-blue-400">CT</p>
                  <p className="text-sm text-gray-400 mt-2">Counter-Terrorists</p>
                  <p className="text-lg font-mono mt-2">$0 total</p>
                </div>
                <div className="text-center p-6 bg-yellow-500/20 rounded-lg border border-yellow-500/30">
                  <p className="text-4xl font-bold text-yellow-400">T</p>
                  <p className="text-sm text-gray-400 mt-2">Terrorists</p>
                  <p className="text-lg font-mono mt-2">$0 total</p>
                </div>
              </div>
              <p className="text-center text-gray-500 mt-4 text-sm">
                💡 Use <code className="bg-default-100 px-2 py-1 rounded">!bet ct/t [amount]</code> in-game to place bets
              </p>
              <p className="text-center text-gray-500 text-sm">
                Min: $1 | Max: $16,000
              </p>
            </CardBody>
          </Card>

          {/* Live Chat */}
          <Card>
            <CardHeader className="flex justify-between items-center">
              <h3 className="text-xl font-bold flex items-center gap-2">
                <IconMessageCircle size={24} className="text-green-400" />
                Live Chat
              </h3>
              <Chip color="primary" variant="flat" size="sm">
                Discord Connected
              </Chip>
            </CardHeader>
            <CardBody>
              <div className="h-64 overflow-y-auto bg-default-100 rounded-lg p-4 mb-4">
                {messages.length === 0 ? (
                  <div className="h-full flex items-center justify-center text-gray-500">
                    <div className="text-center">
                      <IconMessageCircle size={48} className="mx-auto mb-2 opacity-50" />
                      <p>No messages yet</p>
                      <p className="text-sm">Chat messages from Discord will appear here</p>
                    </div>
                  </div>
                ) : (
                  messages.map((msg) => (
                    <div key={msg.id} className="mb-2">
                      <span className="font-bold text-primary">{msg.playerName}</span>
                      <span className="text-gray-400">: </span>
                      <span>{msg.message}</span>
                    </div>
                  ))
                )}
                <div ref={chatEndRef} />
              </div>
              <div className="flex gap-2">
                <Input
                  placeholder="Send message to Discord..."
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                  classNames={{
                    inputWrapper: 'bg-default-100',
                  }}
                />
                <Button
                  color="primary"
                  isIconOnly
                  onClick={sendMessage}
                >
                  <IconSend size={18} />
                </Button>
              </div>
              <p className="text-xs text-gray-500 mt-2">
                💬 Chat is connected to Discord: <a href="https://discord.gg/67C7tjEJ" target="_blank" rel="noreferrer" className="text-primary hover:underline">Join Server</a>
              </p>
            </CardBody>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* VIP Features */}
          <Card className="bg-gradient-to-br from-yellow-500/10 to-orange-500/10 border border-yellow-500/20">
            <CardHeader>
              <h3 className="text-xl font-bold flex items-center gap-2">
                👑 VIP Features
              </h3>
            </CardHeader>
            <CardBody className="space-y-3">
              {vipFeatures.map((feature) => (
                <div
                  key={feature.name}
                  className="flex items-center gap-3 p-2 bg-default-100/50 rounded-lg"
                >
                  <span className="text-2xl">{feature.icon}</span>
                  <div>
                    <p className="font-semibold">{feature.name}</p>
                    <p className="text-xs text-gray-400">{feature.desc}</p>
                  </div>
                </div>
              ))}
              <Button
                color="warning"
                variant="flat"
                fullWidth
                className="mt-4"
                as={Link}
                href="/vip"
              >
                🛒 Get VIP
              </Button>
            </CardBody>
          </Card>

          {/* Discord Widget */}
          <Card>
            <CardHeader>
              <h3 className="text-xl font-bold flex items-center gap-2">
                💬 Discord
              </h3>
            </CardHeader>
            <CardBody className="text-center">
              <p className="text-gray-400 mb-4">Join our community!</p>
              <Button
                color="primary"
                variant="shadow"
                fullWidth
                as="a"
                href="https://discord.gg/67C7tjEJ"
                target="_blank"
              >
                Join Discord
              </Button>
            </CardBody>
          </Card>

          {/* Quick Stats */}
          <Card>
            <CardHeader>
              <h3 className="text-xl font-bold">📊 Quick Stats</h3>
            </CardHeader>
            <CardBody className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-400">Players Today</span>
                <span className="font-bold text-green-400">--</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Total Kills Today</span>
                <span className="font-bold text-red-400">--</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Maps Played</span>
                <span className="font-bold text-blue-400">--</span>
              </div>
              <Button
                as={Link}
                href="/ranks"
                color="primary"
                variant="flat"
                fullWidth
                className="mt-2"
              >
                View Full Rankings
              </Button>
            </CardBody>
          </Card>
        </div>
      </div>
    </div>
  )
}
