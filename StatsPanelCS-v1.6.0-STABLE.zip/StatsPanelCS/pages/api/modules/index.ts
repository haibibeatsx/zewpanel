import type { NextApiRequest, NextApiResponse } from 'next'
import query from '@/utils/functions/db'
import router from '@/lib/Router'

const handler = async (req: NextApiRequest, res: NextApiResponse) => {
	await router.run(req, res)

	const { method } = req

	switch (method) {
		case 'GET': {
			// Get module settings (public)
			const settings = await query.settings.getAll(true)
			
			return res.status(200).json({
				success: true,
				modules: {
					rankings: settings.moduleRankings ?? true,
					store: settings.moduleStore ?? true,
					casino: settings.moduleCasino ?? true,
					vipShop: settings.moduleVipShop ?? true,
					liveStatus: settings.moduleLiveStatus ?? true,
					compare: settings.moduleCompare ?? true,
				}
			})
		}

		case 'PUT': {
			// Update module settings (admin only)
			if (!req.user?.id) {
				return res.status(403).json({ success: false, error: 'Unauthorized' })
			}

			// Check if user is admin
			const admin = await query.admins.getBySteam64(req.user.id)
			if (!admin) {
				return res.status(403).json({ success: false, error: 'Unauthorized - Admin only' })
			}

			const { modules } = req.body

			if (!modules) {
				return res.status(400).json({ success: false, error: 'Missing modules data' })
			}

			try {
				const currentSettings = await query.settings.getAll(false)
				
				await query.settings.update({
					...currentSettings,
					moduleRankings: modules.rankings ?? currentSettings.moduleRankings,
					moduleStore: modules.store ?? currentSettings.moduleStore,
					moduleCasino: modules.casino ?? currentSettings.moduleCasino,
					moduleVipShop: modules.vipShop ?? currentSettings.moduleVipShop,
					moduleLiveStatus: modules.liveStatus ?? currentSettings.moduleLiveStatus,
					moduleCompare: modules.compare ?? currentSettings.moduleCompare,
				})

				return res.status(200).json({ success: true })
			} catch (error: any) {
				return res.status(500).json({ success: false, error: error.message })
			}
		}

		default:
			return res.status(405).json({ success: false, error: 'Method not allowed' })
	}
}

export default handler
