import type { NextApiRequest, NextApiResponse } from 'next'
import mysql from 'mysql2/promise'

// Store Database connection
const getStoreDb = async () => {
  return await mysql.createConnection({
    host: process.env.STORE_DB_HOST || '51.195.117.14',
    port: parseInt(process.env.STORE_DB_PORT || '3306'),
    user: process.env.STORE_DB_USER || 'shop_user',
    password: process.env.STORE_DB_PASSWORD || 'zewcs123',
    database: process.env.STORE_DB_DATABASE || 'shop_zew',
  })
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { action, steamid, amount } = req.query

  try {
    const db = await getStoreDb()

    switch (action) {
      // Get player credits
      case 'credits': {
        if (!steamid) {
          return res.status(400).json({ success: false, error: 'Missing steamid' })
        }

        const [rows] = await db.query(
          'SELECT SteamID, PlayerName, Credits, DateOfJoin, DateOfLastJoin FROM store_players WHERE SteamID = ?',
          [steamid]
        ) as any[]

        await db.end()

        if (rows.length === 0) {
          return res.status(404).json({ success: false, error: 'Player not found' })
        }

        return res.status(200).json({
          success: true,
          data: {
            steamId: rows[0].SteamID,
            name: rows[0].PlayerName,
            credits: rows[0].Credits,
            joinDate: rows[0].DateOfJoin,
            lastJoin: rows[0].DateOfLastJoin,
          }
        })
      }

      // Get top credits leaderboard
      case 'leaderboard': {
        const limit = parseInt(req.query.limit as string) || 10
        const page = parseInt(req.query.page as string) || 1
        const offset = (page - 1) * limit

        const [rows] = await db.query(
          `SELECT SteamID, PlayerName, Credits, DateOfLastJoin 
           FROM store_players 
           ORDER BY Credits DESC 
           LIMIT ? OFFSET ?`,
          [limit, offset]
        ) as any[]

        const [countResult] = await db.query(
          'SELECT COUNT(*) as total FROM store_players'
        ) as any[]

        await db.end()

        return res.status(200).json({
          success: true,
          data: {
            players: rows.map((row: any, index: number) => ({
              position: offset + index + 1,
              steamId: row.SteamID.toString(),
              name: row.PlayerName,
              credits: row.Credits,
              lastJoin: row.DateOfLastJoin,
            })),
            total: countResult[0].total,
            page,
            limit,
          }
        })
      }

      // Get player inventory (items owned)
      case 'inventory': {
        if (!steamid) {
          return res.status(400).json({ success: false, error: 'Missing steamid' })
        }

        const [items] = await db.query(
          `SELECT Type, UniqueId, Price, DateOfPurchase, DateOfExpiration 
           FROM store_items 
           WHERE SteamID = ? AND (DateOfExpiration > NOW() OR DateOfExpiration = '0001-01-01 00:00:00')`,
          [steamid]
        ) as any[]

        const [equipped] = await db.query(
          'SELECT Type, UniqueId, Slot FROM store_equipments WHERE SteamID = ?',
          [steamid]
        ) as any[]

        await db.end()

        return res.status(200).json({
          success: true,
          data: {
            items: items.map((item: any) => ({
              type: item.Type,
              uniqueId: item.UniqueId,
              price: item.Price,
              purchaseDate: item.DateOfPurchase,
              expirationDate: item.DateOfExpiration,
              equipped: equipped.some((e: any) => e.UniqueId === item.UniqueId),
            })),
            equipped: equipped.map((e: any) => ({
              type: e.Type,
              uniqueId: e.UniqueId,
              slot: e.Slot,
            })),
          }
        })
      }

      // Get store stats
      case 'stats': {
        const [totalCredits] = await db.query(
          'SELECT SUM(Credits) as total, AVG(Credits) as avg, COUNT(*) as players FROM store_players'
        ) as any[]

        const [richestPlayer] = await db.query(
          'SELECT SteamID, PlayerName, Credits FROM store_players ORDER BY Credits DESC LIMIT 1'
        ) as any[]

        const [totalItems] = await db.query(
          'SELECT COUNT(*) as total FROM store_items'
        ) as any[]

        await db.end()

        return res.status(200).json({
          success: true,
          data: {
            totalCredits: totalCredits[0].total || 0,
            avgCredits: Math.round(totalCredits[0].avg || 0),
            totalPlayers: totalCredits[0].players || 0,
            totalItems: totalItems[0].total || 0,
            richestPlayer: richestPlayer.length > 0 ? {
              steamId: richestPlayer[0].SteamID.toString(),
              name: richestPlayer[0].PlayerName,
              credits: richestPlayer[0].Credits,
            } : null,
          }
        })
      }

      // Search players by name
      case 'search': {
        const search = req.query.search as string
        if (!search || search.length < 2) {
          return res.status(400).json({ success: false, error: 'Search query too short' })
        }

        const [rows] = await db.query(
          `SELECT SteamID, PlayerName, Credits 
           FROM store_players 
           WHERE PlayerName LIKE ? 
           ORDER BY Credits DESC 
           LIMIT 10`,
          [`%${search}%`]
        ) as any[]

        await db.end()

        return res.status(200).json({
          success: true,
          data: rows.map((row: any) => ({
            steamId: row.SteamID.toString(),
            name: row.PlayerName,
            credits: row.Credits,
          }))
        })
      }

      default:
        await db.end()
        return res.status(400).json({ success: false, error: 'Invalid action' })
    }
  } catch (error: any) {
    console.error('Store API Error:', error)
    return res.status(500).json({ success: false, error: error.message })
  }
}
