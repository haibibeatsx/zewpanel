import passport from '@/lib/Steam'
import router from '@/lib/Router'

const path = '/api/auth/return'

export default router
	.use(path, passport.authenticate('steam', { failureRedirect: '/?login=failed' }))
	.get(path, (_, res) => {
		// Close popup window and reload parent
		res.setHeader('Content-Type', 'text/html')
		res.end(`
			<!DOCTYPE html>
			<html>
			<head><title>Login Successful</title></head>
			<body>
				<script>
					if (window.opener) {
						window.opener.location.reload();
						window.close();
					} else {
						window.location.href = '/';
					}
				</script>
				<p>Login successful! Redirecting...</p>
			</body>
			</html>
		`)
	})
