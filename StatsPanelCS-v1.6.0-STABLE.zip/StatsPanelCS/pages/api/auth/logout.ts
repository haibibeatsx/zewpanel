import type { NextApiRequest, NextApiResponse } from 'next'
import router from '@/lib/Router'

export default router.get('/api/auth/logout', (req: NextApiRequest, res: NextApiResponse) => {
	try {
		// Logout from passport
		if (req.logout) {
			req.logout()
		}
		
		// Clear cookie session by setting it to null
		;(req as any).session = null
		
		// Redirect to home
		res.redirect('/')
	} catch (error) {
		console.error('Logout error:', error)
		res.redirect('/')
	}
})
