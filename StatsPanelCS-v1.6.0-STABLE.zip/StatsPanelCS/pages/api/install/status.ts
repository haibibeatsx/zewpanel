import type { NextApiRequest, NextApiResponse } from 'next'
import fs from 'fs'
import path from 'path'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' })
  }

  // Check if .env exists and has required fields
  const envPath = path.join(process.cwd(), '.env')
  
  if (!fs.existsSync(envPath)) {
    return res.status(200).json({ installed: false, reason: 'No .env file' })
  }

  const envContent = fs.readFileSync(envPath, 'utf-8')
  
  // Check for required fields
  const hasLicense = envContent.includes('LICENSE_KEY=') && !envContent.includes('LICENSE_KEY=SPCS-XXXX')
  const hasSteamKey = envContent.includes('STEAM_API_KEY=') && !envContent.includes('STEAM_API_KEY=your_')
  const hasDatabase = envContent.includes('DB_HOST=') && envContent.includes('DB_DATABASE=')
  
  const installed = hasLicense && hasSteamKey && hasDatabase

  return res.status(200).json({ 
    installed,
    hasLicense,
    hasSteamKey,
    hasDatabase
  })
}
