import type { NextApiRequest, NextApiResponse } from 'next'
import { verifyLicense, isLicenseExpired } from '@/utils/lib/License'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' })
  }

  const licenseKey = process.env.LICENSE_KEY
  const domain = process.env.DOMAIN || req.headers.host || ''
  
  if (!licenseKey) {
    return res.status(200).json({
      valid: false,
      error: 'No license configured',
      trial: true
    })
  }

  const result = verifyLicense(licenseKey, domain)
  
  if (result.valid && result.data) {
    if (isLicenseExpired(result.data.expires)) {
      return res.status(200).json({
        valid: false,
        error: 'License expired',
        expired: true
      })
    }
  }

  return res.status(200).json({
    valid: result.valid,
    error: result.error,
    license: result.valid ? {
      domain: result.data?.domain,
      type: result.data?.type,
      expires: result.data?.expires
    } : null
  })
}
