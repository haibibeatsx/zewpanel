import type { NextApiRequest, NextApiResponse } from 'next'
import Stripe from 'stripe'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '', {
  apiVersion: '2023-10-16',
})

// VIP Packages configuration
const VIP_PACKAGES = {
  bronze: {
    name: 'VIP Bronze',
    price: 299, // in cents (€2.99)
    duration: 30, // days
    description: 'VIP Bronze - 1 Month',
  },
  silver: {
    name: 'VIP Silver',
    price: 499, // €4.99
    duration: 30,
    description: 'VIP Silver - 1 Month',
  },
  gold: {
    name: 'VIP Gold',
    price: 799, // €7.99
    duration: 30,
    description: 'VIP Gold - 1 Month',
  },
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' })
  }

  const { action } = req.body

  try {
    switch (action) {
      case 'create-checkout': {
        const { packageId, steamId, steamName } = req.body

        if (!packageId || !steamId) {
          return res.status(400).json({ error: 'Missing packageId or steamId' })
        }

        const vipPackage = VIP_PACKAGES[packageId as keyof typeof VIP_PACKAGES]
        if (!vipPackage) {
          return res.status(400).json({ error: 'Invalid package' })
        }

        // Create Stripe Checkout Session
        const session = await stripe.checkout.sessions.create({
          payment_method_types: ['card'],
          line_items: [
            {
              price_data: {
                currency: 'eur',
                product_data: {
                  name: vipPackage.name,
                  description: vipPackage.description,
                },
                unit_amount: vipPackage.price,
              },
              quantity: 1,
            },
          ],
          mode: 'payment',
          success_url: `${process.env.DOMAIN || 'http://localhost:3001'}/vip/success?session_id={CHECKOUT_SESSION_ID}`,
          cancel_url: `${process.env.DOMAIN || 'http://localhost:3001'}/vip?canceled=true`,
          metadata: {
            steamId,
            steamName: steamName || 'Unknown',
            packageId,
            packageName: vipPackage.name,
            duration: vipPackage.duration.toString(),
          },
        })

        return res.status(200).json({ 
          success: true, 
          sessionId: session.id,
          url: session.url 
        })
      }

      case 'verify-payment': {
        const { sessionId } = req.body

        if (!sessionId) {
          return res.status(400).json({ error: 'Missing sessionId' })
        }

        const session = await stripe.checkout.sessions.retrieve(sessionId)

        if (session.payment_status === 'paid') {
          // Payment successful - return metadata for VIP activation
          return res.status(200).json({
            success: true,
            paid: true,
            steamId: session.metadata?.steamId,
            packageId: session.metadata?.packageId,
            packageName: session.metadata?.packageName,
            duration: session.metadata?.duration,
            amount: session.amount_total,
            currency: session.currency,
          })
        } else {
          return res.status(200).json({
            success: true,
            paid: false,
            status: session.payment_status,
          })
        }
      }

      default:
        return res.status(400).json({ error: 'Invalid action' })
    }
  } catch (error: any) {
    console.error('Stripe API Error:', error)
    return res.status(500).json({ error: error.message })
  }
}
