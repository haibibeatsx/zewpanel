import type { NextApiRequest, NextApiResponse } from 'next'
import Stripe from 'stripe'
import mysql from 'mysql2/promise'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '', {
  apiVersion: '2023-10-16',
})

// Disable body parsing for webhook
export const config = {
  api: {
    bodyParser: false,
  },
}

// Helper to get raw body
async function getRawBody(req: NextApiRequest): Promise<Buffer> {
  const chunks: Buffer[] = []
  for await (const chunk of req) {
    chunks.push(typeof chunk === 'string' ? Buffer.from(chunk) : chunk)
  }
  return Buffer.concat(chunks)
}

// Database connection for VIPCore
const getVipDb = async () => {
  return await mysql.createConnection({
    host: process.env.DB_HOST || '51.195.117.14',
    port: parseInt(process.env.DB_PORT || '3306'),
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_DATABASE,
  })
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' })
  }

  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET

  if (!webhookSecret) {
    console.error('Missing STRIPE_WEBHOOK_SECRET')
    return res.status(500).json({ error: 'Webhook secret not configured' })
  }

  try {
    const rawBody = await getRawBody(req)
    const signature = req.headers['stripe-signature'] as string

    let event: Stripe.Event

    try {
      event = stripe.webhooks.constructEvent(rawBody, signature, webhookSecret)
    } catch (err: any) {
      console.error('Webhook signature verification failed:', err.message)
      return res.status(400).json({ error: `Webhook Error: ${err.message}` })
    }

    // Handle the event
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session

        if (session.payment_status === 'paid') {
          const steamId = session.metadata?.steamId
          const packageId = session.metadata?.packageId
          const duration = parseInt(session.metadata?.duration || '30')

          if (steamId && packageId) {
            console.log(`VIP Purchase: SteamID=${steamId}, Package=${packageId}, Duration=${duration} days`)

            // Activate VIP in database
            try {
              const db = await getVipDb()

              // Calculate expiration date
              const expiresAt = new Date()
              expiresAt.setDate(expiresAt.getDate() + duration)

              // Map package to VIP group
              const vipGroup = packageId === 'gold' ? 'vip_gold' : 
                               packageId === 'silver' ? 'vip_silver' : 'vip_bronze'

              // Check if player already has VIP
              const [existing] = await db.query(
                'SELECT * FROM vip_users WHERE account_id = ?',
                [steamId]
              ) as any[]

              if (existing.length > 0) {
                // Update existing VIP
                await db.query(
                  'UPDATE vip_users SET `group` = ?, expires = ? WHERE account_id = ?',
                  [vipGroup, Math.floor(expiresAt.getTime() / 1000), steamId]
                )
              } else {
                // Insert new VIP
                await db.query(
                  'INSERT INTO vip_users (account_id, name, `group`, expires) VALUES (?, ?, ?, ?)',
                  [steamId, session.metadata?.steamName || 'Unknown', vipGroup, Math.floor(expiresAt.getTime() / 1000)]
                )
              }

              await db.end()
              console.log(`VIP activated for ${steamId} until ${expiresAt.toISOString()}`)
            } catch (dbError: any) {
              console.error('Database error activating VIP:', dbError.message)
              // Don't fail the webhook - payment was successful
            }
          }
        }
        break
      }

      default:
        console.log(`Unhandled event type: ${event.type}`)
    }

    return res.status(200).json({ received: true })
  } catch (error: any) {
    console.error('Webhook error:', error)
    return res.status(500).json({ error: error.message })
  }
}
