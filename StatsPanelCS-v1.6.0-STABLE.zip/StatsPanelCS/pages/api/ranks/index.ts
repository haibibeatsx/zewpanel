import type { NextApiRequest, NextApiResponse } from 'next'
import mysql from 'mysql2/promise'

// Rank thresholds - configurabile
const RANKS: Record<number, { name: string; icon: string }> = {
  0: { name: 'Unranked', icon: 'unranked' },
  50: { name: 'Silver I', icon: 'silver1' },
  100: { name: 'Silver II', icon: 'silver2' },
  150: { name: 'Silver III', icon: 'silver3' },
  300: { name: 'Silver IV', icon: 'silver4' },
  400: { name: 'Silver Elite', icon: 'silverelite' },
  500: { name: 'Silver Elite Master', icon: 'silverelitemaster' },
  600: { name: 'Gold Nova I', icon: 'goldnova1' },
  700: { name: 'Gold Nova II', icon: 'goldnova2' },
  800: { name: 'Gold Nova III', icon: 'goldnova3' },
  900: { name: 'Gold Nova Master', icon: 'goldnovamaster' },
  1000: { name: 'Master Guardian I', icon: 'mg1' },
  1400: { name: 'Master Guardian II', icon: 'mg2' },
  1600: { name: 'Master Guardian Elite', icon: 'mge' },
  2100: { name: 'Distinguished Master Guardian', icon: 'dmg' },
  2600: { name: 'Legendary Eagle', icon: 'le' },
  2900: { name: 'Legendary Eagle Master', icon: 'lem' },
  3400: { name: 'Supreme Master First Class', icon: 'supreme' },
  4500: { name: 'The Global Elite', icon: 'global' },
}

const getRankFromExp = (exp: number) => {
  const thresholds = Object.keys(RANKS).map(Number).sort((a, b) => b - a)
  for (const threshold of thresholds) {
    if (exp >= threshold) {
      return RANKS[threshold]
    }
  }
  return RANKS[0]
}

const getNextRank = (exp: number) => {
  const thresholds = Object.keys(RANKS).map(Number).sort((a, b) => a - b)
  for (const threshold of thresholds) {
    if (exp < threshold) {
      return { ...RANKS[threshold], expRequired: threshold }
    }
  }
  return null
}

const getRanksConnection = async () => {
  return await mysql.createConnection({
    host: process.env.RANKS_DB_HOST || process.env.DB_HOST,
    port: Number(process.env.RANKS_DB_PORT) || 3306,
    user: process.env.RANKS_DB_USER || 'zewrankv2',
    password: process.env.RANKS_DB_PASSWORD || 'zewrankv2',
    database: process.env.RANKS_DB_DATABASE || 'zew_rankv2',
  })
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { action, steamid, page = '1', limit = '20', search } = req.query

  let connection

  try {
    connection = await getRanksConnection()

    switch (action) {
      case 'leaderboard': {
        const pageNum = parseInt(page as string)
        const limitNum = parseInt(limit as string)
        const offset = (pageNum - 1) * limitNum

        const [countResult] = await connection.execute(
          'SELECT COUNT(*) as total FROM lvl_base'
        ) as any
        const total = countResult[0].total

        const [rows] = await connection.execute(
          `SELECT 
            steam,
            name,
            value as experience,
            kills,
            deaths,
            shoots,
            hits,
            headshots,
            assists,
            round_win,
            round_lose,
            playtime,
            lastconnect
          FROM lvl_base 
          ORDER BY value DESC 
          LIMIT ? OFFSET ?`,
          [limitNum, offset]
        ) as any

        const players = rows.map((row: any, index: number) => {
          const rank = getRankFromExp(row.experience)
          const nextRank = getNextRank(row.experience)
          const kd = row.deaths > 0 ? (row.kills / row.deaths).toFixed(2) : row.kills
          const hsPercent = row.kills > 0 ? ((row.headshots / row.kills) * 100).toFixed(1) : 0

          return {
            position: offset + index + 1,
            steamId: row.steam,
            name: row.name,
            experience: row.experience,
            rank: rank.name,
            rankIcon: rank.icon,
            nextRank: nextRank?.name || 'Max Rank',
            nextRankExp: nextRank?.expRequired || row.experience,
            kills: row.kills,
            deaths: row.deaths,
            assists: row.assists,
            kd: parseFloat(kd as string),
            headshots: row.headshots,
            hsPercent: parseFloat(hsPercent as string),
            roundsWon: row.round_win,
            roundsLost: row.round_lose,
            playtime: row.playtime,
            lastConnect: row.lastconnect,
          }
        })

        return res.status(200).json({
          success: true,
          data: {
            players,
            pagination: {
              page: pageNum,
              limit: limitNum,
              total,
              totalPages: Math.ceil(total / limitNum),
            },
          },
        })
      }

      case 'player': {
        if (!steamid) {
          return res.status(400).json({ success: false, error: 'Steam ID required' })
        }

        const [rows] = await connection.execute(
          `SELECT 
            steam,
            name,
            value as experience,
            kills,
            deaths,
            shoots,
            hits,
            headshots,
            assists,
            round_win,
            round_lose,
            playtime,
            lastconnect
          FROM lvl_base 
          WHERE steam = ?`,
          [steamid]
        ) as any

        if (rows.length === 0) {
          return res.status(404).json({ success: false, error: 'Player not found' })
        }

        const row = rows[0]
        const rank = getRankFromExp(row.experience)
        const nextRank = getNextRank(row.experience)
        const kd = row.deaths > 0 ? (row.kills / row.deaths).toFixed(2) : row.kills
        const hsPercent = row.kills > 0 ? ((row.headshots / row.kills) * 100).toFixed(1) : 0
        const accuracy = row.shoots > 0 ? ((row.hits / row.shoots) * 100).toFixed(1) : 0

        const [posResult] = await connection.execute(
          'SELECT COUNT(*) as position FROM lvl_base WHERE value > ?',
          [row.experience]
        ) as any

        return res.status(200).json({
          success: true,
          data: {
            position: posResult[0].position + 1,
            steamId: row.steam,
            name: row.name,
            experience: row.experience,
            rank: rank.name,
            rankIcon: rank.icon,
            nextRank: nextRank?.name || 'Max Rank',
            nextRankExp: nextRank?.expRequired || row.experience,
            expProgress: nextRank
              ? ((row.experience / nextRank.expRequired) * 100).toFixed(1)
              : 100,
            kills: row.kills,
            deaths: row.deaths,
            assists: row.assists,
            kd: parseFloat(kd as string),
            headshots: row.headshots,
            hsPercent: parseFloat(hsPercent as string),
            shoots: row.shoots,
            hits: row.hits,
            accuracy: parseFloat(accuracy as string),
            roundsWon: row.round_win,
            roundsLost: row.round_lose,
            winRate: row.round_win + row.round_lose > 0
              ? ((row.round_win / (row.round_win + row.round_lose)) * 100).toFixed(1)
              : 0,
            playtime: row.playtime,
            lastConnect: row.lastconnect,
          },
        })
      }

      case 'search': {
        if (!search) {
          return res.status(400).json({ success: false, error: 'Search query required' })
        }

        const [rows] = await connection.execute(
          `SELECT 
            steam,
            name,
            value as experience,
            kills,
            deaths,
            headshots
          FROM lvl_base 
          WHERE name LIKE ? 
          ORDER BY value DESC 
          LIMIT 20`,
          [`%${search}%`]
        ) as any

        const players = rows.map((row: any) => {
          const rank = getRankFromExp(row.experience)
          return {
            steamId: row.steam,
            name: row.name,
            experience: row.experience,
            rank: rank.name,
            rankIcon: rank.icon,
            kills: row.kills,
            deaths: row.deaths,
          }
        })

        return res.status(200).json({
          success: true,
          data: players,
        })
      }

      case 'stats': {
        const [statsResult] = await connection.execute(
          `SELECT 
            COUNT(*) as totalPlayers,
            SUM(kills) as totalKills,
            SUM(deaths) as totalDeaths,
            SUM(headshots) as totalHeadshots,
            SUM(playtime) as totalPlaytime,
            AVG(value) as avgExperience
          FROM lvl_base`
        ) as any

        return res.status(200).json({
          success: true,
          data: statsResult[0],
        })
      }

      default:
        return res.status(400).json({ success: false, error: 'Invalid action' })
    }
  } catch (error: any) {
    console.error('[Ranks API Error]:', error)
    return res.status(500).json({ success: false, error: error.message })
  } finally {
    if (connection) {
      await connection.end()
    }
  }
}
