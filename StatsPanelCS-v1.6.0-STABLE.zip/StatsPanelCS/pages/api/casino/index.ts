import type { NextApiRequest, NextApiResponse } from 'next'
import mysql from 'mysql2/promise'

// Store Database connection
const getStoreDb = async () => {
  return await mysql.createConnection({
    host: process.env.STORE_DB_HOST || '51.195.117.14',
    port: parseInt(process.env.STORE_DB_PORT || '3306'),
    user: process.env.STORE_DB_USER || 'shop_user',
    password: process.env.STORE_DB_PASSWORD || 'zewcs123',
    database: process.env.STORE_DB_DATABASE || 'shop_zew',
  })
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ success: false, error: 'Method not allowed' })
  }

  const { action, steamid, amount, game, result } = req.body

  if (!steamid) {
    return res.status(400).json({ success: false, error: 'Missing steamid' })
  }

  try {
    const db = await getStoreDb()

    switch (action) {
      // Deduct credits (place bet)
      case 'bet': {
        if (!amount || amount <= 0) {
          await db.end()
          return res.status(400).json({ success: false, error: 'Invalid amount' })
        }

        // Check current balance
        const [rows] = await db.query(
          'SELECT Credits FROM store_players WHERE SteamID = ?',
          [steamid]
        ) as any[]

        if (rows.length === 0) {
          await db.end()
          return res.status(404).json({ success: false, error: 'Player not found' })
        }

        const currentCredits = rows[0].Credits

        if (currentCredits < amount) {
          await db.end()
          return res.status(400).json({ success: false, error: 'Insufficient credits' })
        }

        // Deduct credits
        await db.query(
          'UPDATE store_players SET Credits = Credits - ? WHERE SteamID = ?',
          [amount, steamid]
        )

        await db.end()
        return res.status(200).json({
          success: true,
          newBalance: currentCredits - amount
        })
      }

      // Add credits (win)
      case 'win': {
        if (!amount || amount <= 0) {
          await db.end()
          return res.status(400).json({ success: false, error: 'Invalid amount' })
        }

        // Add credits
        await db.query(
          'UPDATE store_players SET Credits = Credits + ? WHERE SteamID = ?',
          [amount, steamid]
        )

        // Get new balance
        const [rows] = await db.query(
          'SELECT Credits FROM store_players WHERE SteamID = ?',
          [steamid]
        ) as any[]

        await db.end()
        return res.status(200).json({
          success: true,
          newBalance: rows[0]?.Credits || 0
        })
      }

      // Play game (all in one - bet and result)
      case 'play': {
        if (!amount || amount <= 0 || !game) {
          await db.end()
          return res.status(400).json({ success: false, error: 'Invalid parameters' })
        }

        // Check current balance
        const [rows] = await db.query(
          'SELECT Credits FROM store_players WHERE SteamID = ?',
          [steamid]
        ) as any[]

        if (rows.length === 0) {
          await db.end()
          return res.status(404).json({ success: false, error: 'Player not found' })
        }

        const currentCredits = rows[0].Credits

        if (currentCredits < amount) {
          await db.end()
          return res.status(400).json({ success: false, error: 'Insufficient credits' })
        }

        let won = false
        let winAmount = 0
        let gameResult: any = {}

        // Game logic
        switch (game) {
          case 'coinflip': {
            const choice = req.body.choice // 'heads' or 'tails'
            const flipResult = Math.random() < 0.5 ? 'heads' : 'tails'
            won = flipResult === choice
            winAmount = won ? amount * 2 : 0
            gameResult = { flipResult, won }
            break
          }

          case 'roulette': {
            const choice = req.body.choice // 'red', 'black', or 'green'
            const number = Math.floor(Math.random() * 37) // 0-36
            const isGreen = number === 0
            const redNumbers = [1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36]
            const isRed = redNumbers.includes(number)
            const isBlack = !isGreen && !isRed

            if (choice === 'green' && isGreen) {
              won = true
              winAmount = amount * 14
            } else if (choice === 'red' && isRed) {
              won = true
              winAmount = amount * 2
            } else if (choice === 'black' && isBlack) {
              won = true
              winAmount = amount * 2
            }

            gameResult = { number, color: isGreen ? 'green' : isRed ? 'red' : 'black', won }
            break
          }

          case 'crash': {
            // Generate crash point (house edge ~5%)
            const crashPoint = Math.max(1.0, (100 / (Math.random() * 100 + 1)))
            const cashoutAt = req.body.cashoutAt || 0

            if (cashoutAt > 0 && cashoutAt <= crashPoint) {
              won = true
              winAmount = Math.floor(amount * cashoutAt)
            }

            gameResult = { crashPoint: Math.min(crashPoint, 100).toFixed(2), cashoutAt, won }
            break
          }

          default:
            await db.end()
            return res.status(400).json({ success: false, error: 'Invalid game' })
        }

        // Update credits in database
        const newCredits = currentCredits - amount + winAmount

        await db.query(
          'UPDATE store_players SET Credits = ? WHERE SteamID = ?',
          [newCredits, steamid]
        )

        await db.end()
        return res.status(200).json({
          success: true,
          won,
          winAmount,
          netResult: winAmount - amount,
          newBalance: newCredits,
          game: gameResult
        })
      }

      default:
        await db.end()
        return res.status(400).json({ success: false, error: 'Invalid action' })
    }
  } catch (error: any) {
    console.error('Casino API Error:', error)
    return res.status(500).json({ success: false, error: error.message })
  }
}
