# 🎮 StatsPanelCS v1.5.0

**Professional CS2 Server Statistics Panel by ElProfessor**

---

## 📋 Cerințe

- **Node.js** 18+ (recomandat 20+)
- **MySQL** 5.7+ sau MariaDB 10+
- **CS2-SimpleAdmin** plugin instalat pe server
- **PM2** sau **Screen** (pentru a rula în background)
- **(Opțional)** RanksCore, CS2-Store plugins

---

## 🚀 Instalare

### Metoda 1: VPS/Dedicated Server (SFTP/SSH)

#### 1. Conectează-te prin SSH
```bash
ssh user@ip-server
```

#### 2. Instalează Node.js (dacă nu e instalat)
```bash
# Ubuntu/Debian
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# CentOS/RHEL
curl -fsSL https://rpm.nodesource.com/setup_20.x | sudo bash -
sudo yum install -y nodejs

# Verifică versiunea
node -v  # trebuie să fie 18+
npm -v
```

#### 3. Upload fișierele
**Opțiunea A - SFTP (FileZilla, WinSCP):**
- Conectează-te la server prin SFTP
- Upload folderul `StatsPanelCS` în `/home/user/` sau `/var/www/`

**Opțiunea B - wget/curl:**
```bash
cd /home/user
wget https://link-download/StatsPanelCS-v1.5.0.zip
unzip StatsPanelCS-v1.5.0.zip
cd StatsPanelCS
```

#### 4. Instalează dependențele
```bash
cd StatsPanelCS
npm install --legacy-peer-deps
```

#### 5. Build proiectul
```bash
npm run build
```

#### 6. Pornește și configurează
```bash
# Pornește temporar pentru configurare
npm run start -- -p 3001

# Accesează în browser: http://ip-server:3001/install
# Urmează wizard-ul de instalare
```

#### 7. Rulează permanent cu PM2
```bash
# Instalează PM2 (o singură dată)
sudo npm install -g pm2

# Pornește aplicația
pm2 start npm --name "statspanel" -- run start -- -p 3001

# Salvează pentru restart automat
pm2 save
pm2 startup
```

#### 8. (Opțional) Configurare Nginx Reverse Proxy
```nginx
# /etc/nginx/sites-available/stats.domeniu.com
server {
    listen 80;
    server_name stats.domeniu.com;

    location / {
        proxy_pass http://127.0.0.1:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_cache_bypass $http_upgrade;
    }
}
```

```bash
# Activează site-ul
sudo ln -s /etc/nginx/sites-available/stats.domeniu.com /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx

# SSL cu Certbot
sudo certbot --nginx -d stats.domeniu.com
```

---

### Metoda 2: Pterodactyl Panel

#### 1. Importă Egg-ul
- Admin Panel → Nests → Import Egg
- Upload `egg-stats-panel-cs.json`

#### 2. Creează Server
- Selectează egg-ul "Stats Panel CS"
- Completează variabilele
- Start server

#### 3. Configurează
- Accesează `https://domeniu/install`
- Urmează wizard-ul

---

### Metoda 3: Docker

```bash
# Build
docker build -t statspanelcs .

# Run
docker run -d \
  -p 3001:3001 \
  -e LICENSE_KEY=SPCS-XXXX-XXXX-XXXX-XXXX \
  -e LICENSED_DOMAIN=stats.domeniu.com \
  -e STEAM_API_KEY=your_key \
  -e DOMAIN=https://stats.domeniu.com \
  -e DB_HOST=db_host \
  -e DB_USER=db_user \
  -e DB_PASSWORD=db_pass \
  -e DB_DATABASE=db_name \
  --name statspanel \
  statspanelcs
```

---

## ⚙️ Configurare .env

Dacă preferi să configurezi manual (fără wizard):

```env
# License (OBLIGATORIU)
LICENSE_KEY=SPCS-XXXX-XXXX-XXXX-XXXX
LICENSED_DOMAIN=stats.domeniu.com
LICENSE_EMAIL=email@example.com
LICENSE_TYPE=standard
LICENSE_EXPIRES=2026-01-01

# Steam API
STEAM_API_KEY=your_steam_api_key

# Domain
DOMAIN=https://stats.domeniu.com

# Database - CS2-SimpleAdmin
DB_HOST=127.0.0.1
DB_PORT=3306
DB_USER=user
DB_PASSWORD=password
DB_DATABASE=simpleadmin

# Master Admin
MASTER_ADMIN=76561198000000000
SESSION_SECRET=random_string_here

# RanksCore (opțional)
RANKS_DB_HOST=127.0.0.1
RANKS_DB_PORT=3306
RANKS_DB_USER=user
RANKS_DB_PASSWORD=password
RANKS_DB_DATABASE=ranks

# CS2-Store (opțional)
STORE_DB_HOST=127.0.0.1
STORE_DB_PORT=3306
STORE_DB_USER=user
STORE_DB_PASSWORD=password
STORE_DB_DATABASE=store

# Stripe VIP (opțional)
STRIPE_SECRET_KEY=sk_live_xxx
STRIPE_PUBLISHABLE_KEY=pk_live_xxx
STRIPE_WEBHOOK_SECRET=whsec_xxx
```

---

## 🔧 Comenzi Utile

```bash
# Development
npm run dev

# Build producție
npm run build

# Start producție
npm run start -- -p 3001

# PM2 comenzi
pm2 start npm --name "statspanel" -- run start -- -p 3001
pm2 stop statspanel
pm2 restart statspanel
pm2 logs statspanel
pm2 delete statspanel

# Screen (alternativă la PM2)
screen -S statspanel
npm run start -- -p 3001
# CTRL+A+D pentru a ieși din screen
screen -r statspanel  # pentru a reveni
```

---

## 🔥 Firewall

```bash
# Ubuntu/Debian (UFW)
sudo ufw allow 3001/tcp

# CentOS/RHEL (firewalld)
sudo firewall-cmd --permanent --add-port=3001/tcp
sudo firewall-cmd --reload
```

---

## ❓ Troubleshooting

### "Cannot find module"
```bash
rm -rf node_modules package-lock.json
npm install --legacy-peer-deps
```

### "EACCES permission denied"
```bash
sudo chown -R $USER:$USER /home/user/StatsPanelCS
```

### Port deja folosit
```bash
# Verifică ce folosește portul
sudo lsof -i :3001
# Schimbă portul
npm run start -- -p 3002
```

### Database connection refused
- Verifică că MySQL/MariaDB rulează
- Verifică credențialele în .env
- Verifică că user-ul are permisiuni pentru baza de date
- Verifică firewall-ul pentru portul MySQL

---

## 📞 Suport

- **Discord:** [link]
- **Email:** support@elprofessor.dev

---

## 📜 License

© 2025 ElProfessor. All rights reserved.
Unauthorized distribution is prohibited.
