#!/usr/bin/env node

/**
 * StatsPanelCS License Generator
 * Usage: node generate-license.js <domain> <email> <type> [expires]
 * 
 * Types: standard, extended, lifetime
 * Expires: YYYY-MM-DD or 'lifetime'
 * 
 * Example: node generate-license.js stats.example.com client@email.com standard 2025-12-31
 */

const crypto = require('crypto')

const LICENSE_SECRET = 'StatsPanelCS-ElProfessor-2025-SecretKey'

function generateLicense(domain, email, type, expires) {
  const data = {
    domain,
    email,
    type,
    expires: expires || 'lifetime',
    createdAt: new Date().toISOString()
  }
  
  const payload = JSON.stringify(data)
  
  const signature = crypto
    .createHmac('sha256', LICENSE_SECRET)
    .update(payload)
    .digest('hex')
    .substring(0, 16)
  
  const licenseKey = `SPCS-${signature.substring(0, 4).toUpperCase()}-${signature.substring(4, 8).toUpperCase()}-${signature.substring(8, 12).toUpperCase()}-${signature.substring(12, 16).toUpperCase()}`
  
  return { licenseKey, data }
}

// Parse arguments
const args = process.argv.slice(2)

if (args.length < 3) {
  console.log(`
╔═══════════════════════════════════════════════════════════╗
║         StatsPanelCS License Generator                    ║
║                  by ElProfessor                           ║
╠═══════════════════════════════════════════════════════════╣
║  Usage:                                                   ║
║    node generate-license.js <domain> <email> <type>       ║
║                                                           ║
║  Types:                                                   ║
║    - standard  (1 domain, 1 year)                         ║
║    - extended  (1 domain, lifetime updates)               ║
║    - lifetime  (1 domain, lifetime everything)            ║
║                                                           ║
║  Example:                                                 ║
║    node generate-license.js stats.zewcs.com \\             ║
║         client@email.com standard 2025-12-31              ║
╚═══════════════════════════════════════════════════════════╝
  `)
  process.exit(1)
}

const [domain, email, type, expires] = args

const result = generateLicense(domain, email, type, expires)

console.log(`
╔═══════════════════════════════════════════════════════════╗
║              LICENSE GENERATED SUCCESSFULLY               ║
╠═══════════════════════════════════════════════════════════╣

  License Key: ${result.licenseKey}

  Domain:      ${result.data.domain}
  Email:       ${result.data.email}
  Type:        ${result.data.type}
  Expires:     ${result.data.expires}
  Created:     ${result.data.createdAt}

╠═══════════════════════════════════════════════════════════╣
║  Add to client's .env file:                               ║
╠═══════════════════════════════════════════════════════════╣

LICENSE_KEY=${result.licenseKey}
LICENSED_DOMAIN=${result.data.domain}
LICENSE_EMAIL=${result.data.email}
LICENSE_TYPE=${result.data.type}
LICENSE_EXPIRES=${result.data.expires}

╚═══════════════════════════════════════════════════════════╝
`)
