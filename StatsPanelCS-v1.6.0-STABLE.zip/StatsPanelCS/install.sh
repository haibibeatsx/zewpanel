#!/bin/bash

# ================================================
# StatsPanelCS Auto-Installer
# by ElProfessor
# ================================================

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}"
echo "╔═══════════════════════════════════════════════════════════╗"
echo "║           🎮 StatsPanelCS Auto-Installer                  ║"
echo "║                  by ElProfessor                           ║"
echo "╚═══════════════════════════════════════════════════════════╝"
echo -e "${NC}"

# Check if running as root
if [ "$EUID" -eq 0 ]; then
    echo -e "${YELLOW}⚠️  Running as root. It's recommended to run as a normal user.${NC}"
fi

# Check Node.js
echo -e "${BLUE}[1/6]${NC} Checking Node.js..."
if command -v node &> /dev/null; then
    NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
    if [ "$NODE_VERSION" -ge 18 ]; then
        echo -e "${GREEN}✓ Node.js $(node -v) installed${NC}"
    else
        echo -e "${RED}✗ Node.js version too old. Need 18+${NC}"
        echo -e "${YELLOW}Installing Node.js 20...${NC}"
        curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
        sudo apt install -y nodejs
    fi
else
    echo -e "${YELLOW}Node.js not found. Installing...${NC}"
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt install -y nodejs
fi

# Check npm
echo -e "${BLUE}[2/6]${NC} Checking npm..."
if command -v npm &> /dev/null; then
    echo -e "${GREEN}✓ npm $(npm -v) installed${NC}"
else
    echo -e "${RED}✗ npm not found${NC}"
    exit 1
fi

# Install dependencies
echo -e "${BLUE}[3/6]${NC} Installing dependencies..."
npm install --legacy-peer-deps
if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Dependencies installed${NC}"
else
    echo -e "${RED}✗ Failed to install dependencies${NC}"
    exit 1
fi

# Build project
echo -e "${BLUE}[4/6]${NC} Building project..."
npm run build
if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Build successful${NC}"
else
    echo -e "${RED}✗ Build failed${NC}"
    exit 1
fi

# Install PM2
echo -e "${BLUE}[5/6]${NC} Setting up PM2..."
if command -v pm2 &> /dev/null; then
    echo -e "${GREEN}✓ PM2 already installed${NC}"
else
    echo -e "${YELLOW}Installing PM2...${NC}"
    sudo npm install -g pm2
fi

# Ask for port
echo ""
read -p "Enter port number (default: 3001): " PORT
PORT=${PORT:-3001}

# Start with PM2
echo -e "${BLUE}[6/6]${NC} Starting application..."
pm2 delete statspanel 2>/dev/null
pm2 start npm --name "statspanel" -- run start -- -p $PORT
pm2 save

echo ""
echo -e "${GREEN}"
echo "╔═══════════════════════════════════════════════════════════╗"
echo "║            ✅ Installation Complete!                      ║"
echo "╠═══════════════════════════════════════════════════════════╣"
echo "║                                                           ║"
echo "║  Panel URL: http://YOUR_IP:$PORT                          ║"
echo "║  Install:   http://YOUR_IP:$PORT/install                  ║"
echo "║                                                           ║"
echo "║  PM2 Commands:                                            ║"
echo "║    pm2 logs statspanel    - View logs                     ║"
echo "║    pm2 restart statspanel - Restart panel                 ║"
echo "║    pm2 stop statspanel    - Stop panel                    ║"
echo "║                                                           ║"
echo "╚═══════════════════════════════════════════════════════════╝"
echo -e "${NC}"

# Setup PM2 startup
echo -e "${YELLOW}Setting up auto-start on reboot...${NC}"
pm2 startup
echo -e "${GREEN}Done! Run the command above if prompted.${NC}"
