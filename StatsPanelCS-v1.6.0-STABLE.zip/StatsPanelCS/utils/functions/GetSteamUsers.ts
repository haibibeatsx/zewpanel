import { From64ToUser } from 'steam-api-sdk'

/**
 * Get a duplicate-free version of an array of steam-64 ids and return steam users
 */
const GetSteamUsers = async (steamIds: string[]) => {
	const uniqueSteamIds = [...new Set(steamIds)]
		// Filter the non steam64 values (not numbers or invalid length)
		.filter((steamid) => {
			if (!steamid) return false
			if (isNaN(Number(steamid))) return false
			// Valid Steam64 IDs are 17 digits and start with 7656
			if (steamid.length !== 17) return false
			if (!steamid.startsWith('7656')) return false
			return true
		})

	// If there are no valid steam64 ids, return an empty array
	if (!uniqueSteamIds.length) return []

	try {
		// Get the steam profiles
		const profiles = await From64ToUser(uniqueSteamIds)
		return profiles || []
	} catch (error) {
		console.error('Steam API Error:', error)
		return []
	}
}

export default GetSteamUsers
