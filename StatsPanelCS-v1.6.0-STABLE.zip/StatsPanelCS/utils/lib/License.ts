import crypto from 'crypto'

// Secret key for license generation (KEEP THIS PRIVATE!)
const LICENSE_SECRET = process.env.LICENSE_SECRET || 'StatsPanelCS-ElProfessor-2025-SecretKey'

interface LicenseData {
  domain: string
  email: string
  type: 'standard' | 'extended' | 'lifetime'
  expires: string // ISO date or 'lifetime'
  createdAt: string
}

/**
 * Generate a license key for a domain
 */
export function generateLicense(data: LicenseData): string {
  const payload = JSON.stringify(data)
  const base64Payload = Buffer.from(payload).toString('base64')
  
  // Create signature
  const signature = crypto
    .createHmac('sha256', LICENSE_SECRET)
    .update(payload)
    .digest('hex')
    .substring(0, 16)
  
  // Format: SPCS-XXXX-XXXX-XXXX-XXXX
  const licenseKey = `SPCS-${signature.substring(0, 4).toUpperCase()}-${signature.substring(4, 8).toUpperCase()}-${signature.substring(8, 12).toUpperCase()}-${signature.substring(12, 16).toUpperCase()}`
  
  return licenseKey
}

/**
 * Verify a license key
 */
export function verifyLicense(licenseKey: string, domain: string): { valid: boolean; error?: string; data?: LicenseData } {
  try {
    // Check format
    if (!licenseKey || !licenseKey.startsWith('SPCS-')) {
      return { valid: false, error: 'Invalid license format' }
    }

    // For now, we'll use a simple API check
    // In production, this would check against your license server
    
    const storedLicense = process.env.LICENSE_KEY
    const licensedDomain = process.env.LICENSED_DOMAIN
    
    if (!storedLicense || !licensedDomain) {
      return { valid: false, error: 'License not configured' }
    }
    
    if (licenseKey !== storedLicense) {
      return { valid: false, error: 'Invalid license key' }
    }
    
    // Check domain
    const currentDomain = domain.replace(/^https?:\/\//, '').replace(/\/$/, '')
    const licensed = licensedDomain.replace(/^https?:\/\//, '').replace(/\/$/, '')
    
    if (currentDomain !== licensed && !currentDomain.includes('localhost')) {
      return { valid: false, error: 'License not valid for this domain' }
    }
    
    return { 
      valid: true,
      data: {
        domain: licensedDomain,
        email: process.env.LICENSE_EMAIL || '',
        type: (process.env.LICENSE_TYPE as any) || 'standard',
        expires: process.env.LICENSE_EXPIRES || 'lifetime',
        createdAt: process.env.LICENSE_CREATED || new Date().toISOString()
      }
    }
  } catch (error) {
    return { valid: false, error: 'License verification failed' }
  }
}

/**
 * Check if license is expired
 */
export function isLicenseExpired(expires: string): boolean {
  if (expires === 'lifetime') return false
  
  const expiryDate = new Date(expires)
  return expiryDate < new Date()
}

export default {
  generateLicense,
  verifyLicense,
  isLicenseExpired
}
