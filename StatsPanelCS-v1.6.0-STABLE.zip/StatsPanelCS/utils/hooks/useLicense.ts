'use client'

import { useEffect, useState } from 'react'

interface LicenseStatus {
  valid: boolean
  error?: string
  trial?: boolean
  expired?: boolean
  license?: {
    domain: string
    type: string
    expires: string
  }
}

export function useLicense() {
  const [status, setStatus] = useState<LicenseStatus | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const checkLicense = async () => {
      try {
        const res = await fetch('/api/license')
        const data = await res.json()
        setStatus(data)
      } catch (error) {
        setStatus({ valid: false, error: 'Failed to verify license' })
      }
      setLoading(false)
    }

    checkLicense()
  }, [])

  return { status, loading }
}

export default useLicense
