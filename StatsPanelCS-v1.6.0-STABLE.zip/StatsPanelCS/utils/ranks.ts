// CS2 Rank Icons - SVG components
export const RANK_ICONS: Record<string, string> = {
  'Unranked': '❓',
  'Silver I': '⬜',
  'Silver II': '⬜',
  'Silver III': '⬜', 
  'Silver IV': '⬜',
  'Silver Elite': '⬜',
  'Silver Elite Master': '⬜',
  'Gold Nova I': '🟨',
  'Gold Nova II': '🟨',
  'Gold Nova III': '🟨',
  'Gold Nova Master': '🟨',
  'Master Guardian I': '🟦',
  'Master Guardian II': '🟦',
  'Master Guardian Elite': '🟦',
  'Distinguished Master Guardian': '⭐',
  'Legendary Eagle': '🦅',
  'Legendary Eagle Master': '🦅',
  'Supreme Master First Class': '💎',
  'The Global Elite': '🌍',
}

export const getRankEmoji = (rank: string): string => {
  return RANK_ICONS[rank] || '❓'
}

export const getRankTier = (rank: string): 'silver' | 'gold' | 'mg' | 'eagle' | 'supreme' | 'global' | 'unranked' => {
  if (rank.includes('Silver')) return 'silver'
  if (rank.includes('Gold')) return 'gold'
  if (rank.includes('Master Guardian') || rank.includes('Distinguished')) return 'mg'
  if (rank.includes('Legendary')) return 'eagle'
  if (rank.includes('Supreme')) return 'supreme'
  if (rank.includes('Global')) return 'global'
  return 'unranked'
}

export const RANK_COLORS: Record<string, string> = {
  silver: '#A0A0A0',
  gold: '#FFD700',
  mg: '#4169E1',
  eagle: '#9932CC',
  supreme: '#DC143C',
  global: '#00CED1',
  unranked: '#808080',
}
