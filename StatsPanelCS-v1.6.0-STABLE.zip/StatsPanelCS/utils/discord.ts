import axios from 'axios'

interface DiscordEmbed {
  title?: string
  description?: string
  color?: number
  fields?: Array<{
    name: string
    value: string
    inline?: boolean
  }>
  thumbnail?: {
    url: string
  }
  footer?: {
    text: string
    icon_url?: string
  }
  timestamp?: string
}

interface DiscordWebhookPayload {
  username?: string
  avatar_url?: string
  content?: string
  embeds?: DiscordEmbed[]
}

export const sendDiscordNotification = async (
  webhookUrl: string,
  payload: DiscordWebhookPayload
): Promise<boolean> => {
  if (!webhookUrl) return false
  
  try {
    await axios.post(webhookUrl, payload)
    return true
  } catch (error) {
    console.error('[Discord Webhook Error]:', error)
    return false
  }
}

// Colors for different notification types
export const DISCORD_COLORS = {
  ban: 0xFF0000,      // Red
  unban: 0x00FF00,    // Green
  mute: 0xFFA500,     // Orange
  unmute: 0x00FF00,   // Green
  kick: 0xFFFF00,     // Yellow
  newPlayer: 0x0099FF, // Blue
  topPlayer: 0xFFD700, // Gold
  serverAlert: 0x9932CC, // Purple
}

// Pre-built notification functions
export const notifyBan = async (
  webhookUrl: string,
  playerName: string,
  adminName: string,
  reason: string,
  duration: string,
  steamId: string
) => {
  return sendDiscordNotification(webhookUrl, {
    username: 'CS2 Panel',
    embeds: [{
      title: '🔨 Player Banned',
      color: DISCORD_COLORS.ban,
      fields: [
        { name: 'Player', value: playerName, inline: true },
        { name: 'Admin', value: adminName, inline: true },
        { name: 'Duration', value: duration, inline: true },
        { name: 'Reason', value: reason || 'No reason provided', inline: false },
        { name: 'Steam ID', value: steamId, inline: false },
      ],
      timestamp: new Date().toISOString(),
      footer: { text: 'ZewCS Panel' }
    }]
  })
}

export const notifyUnban = async (
  webhookUrl: string,
  playerName: string,
  adminName: string,
  steamId: string
) => {
  return sendDiscordNotification(webhookUrl, {
    username: 'CS2 Panel',
    embeds: [{
      title: '✅ Player Unbanned',
      color: DISCORD_COLORS.unban,
      fields: [
        { name: 'Player', value: playerName, inline: true },
        { name: 'Admin', value: adminName, inline: true },
        { name: 'Steam ID', value: steamId, inline: false },
      ],
      timestamp: new Date().toISOString(),
      footer: { text: 'ZewCS Panel' }
    }]
  })
}

export const notifyMute = async (
  webhookUrl: string,
  playerName: string,
  adminName: string,
  reason: string,
  duration: string,
  muteType: string
) => {
  return sendDiscordNotification(webhookUrl, {
    username: 'CS2 Panel',
    embeds: [{
      title: '🔇 Player Muted',
      color: DISCORD_COLORS.mute,
      fields: [
        { name: 'Player', value: playerName, inline: true },
        { name: 'Admin', value: adminName, inline: true },
        { name: 'Type', value: muteType, inline: true },
        { name: 'Duration', value: duration, inline: true },
        { name: 'Reason', value: reason || 'No reason provided', inline: false },
      ],
      timestamp: new Date().toISOString(),
      footer: { text: 'ZewCS Panel' }
    }]
  })
}

export const notifyTopPlayer = async (
  webhookUrl: string,
  playerName: string,
  rank: string,
  position: number,
  experience: number
) => {
  return sendDiscordNotification(webhookUrl, {
    username: 'CS2 Panel',
    embeds: [{
      title: '🏆 New Top Player!',
      description: `**${playerName}** has reached **#${position}** on the leaderboard!`,
      color: DISCORD_COLORS.topPlayer,
      fields: [
        { name: 'Rank', value: rank, inline: true },
        { name: 'Experience', value: experience.toLocaleString() + ' XP', inline: true },
      ],
      timestamp: new Date().toISOString(),
      footer: { text: 'ZewCS Panel' }
    }]
  })
}

export const notifyServerStatus = async (
  webhookUrl: string,
  serverName: string,
  status: 'online' | 'offline',
  players?: number,
  maxPlayers?: number
) => {
  return sendDiscordNotification(webhookUrl, {
    username: 'CS2 Panel',
    embeds: [{
      title: status === 'online' ? '🟢 Server Online' : '🔴 Server Offline',
      description: serverName,
      color: status === 'online' ? 0x00FF00 : 0xFF0000,
      fields: players !== undefined ? [
        { name: 'Players', value: `${players}/${maxPlayers}`, inline: true },
      ] : [],
      timestamp: new Date().toISOString(),
      footer: { text: 'ZewCS Panel' }
    }]
  })
}
